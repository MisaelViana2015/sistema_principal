import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";

// Pages
import Login from "@/pages/Login";
import Turno from "@/pages/Turno";
import AdicionarCorrida from "@/pages/AdicionarCorrida";
import AdicionarCusto from "@/pages/AdicionarCusto";
import EncerrarTurno from "@/pages/EncerrarTurno";
import Veiculos from "@/pages/Veiculos";
import Motoristas from "@/pages/Motoristas";
import Logs from "@/pages/Logs";
import Admin from "@/pages/Admin";
import NotFound from "@/pages/not-found";
import RepairStuck from "@/pages/RepairStuck"; // << NOVO

function ProtectedRoute({
  component: Component,
  adminOnly = false,
}: {
  component: React.ComponentType;
  adminOnly?: boolean;
}) {
  const { user, isAdmin } = useAuth();

  if (!user) return <Redirect to="/login" />;
  if (adminOnly && !isAdmin) return <Redirect to="/" />;
  return <Component />;
}

function Router() {
  const { user } = useAuth();

  return (
    <Switch>
      <Route path="/login">{user ? <Redirect to="/" /> : <Login />}</Route>
      <Route path="/">
        <ProtectedRoute component={Turno} />
      </Route>
      <Route path="/turno/adicionar-corrida">
        <ProtectedRoute component={AdicionarCorrida} />
      </Route>
      <Route path="/turno/adicionar-custo">
        <ProtectedRoute component={AdicionarCusto} />
      </Route>
      <Route path="/turno/encerrar">
        <ProtectedRoute component={EncerrarTurno} />
      </Route>
      <Route path="/veiculos">
        <ProtectedRoute component={Veiculos} />
      </Route>
      <Route path="/motoristas">
        <ProtectedRoute component={Motoristas} />
      </Route>
      <Route path="/logs">
        <ProtectedRoute component={Logs} />
      </Route>
      <Route path="/admin">
        <ProtectedRoute component={Admin} adminOnly />
      </Route>

      {/* NOVO: ferramenta de reparo (apenas admin) */}
      <Route path="/admin/repair-stuck">
        <ProtectedRoute component={RepairStuck} adminOnly />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Router />
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
