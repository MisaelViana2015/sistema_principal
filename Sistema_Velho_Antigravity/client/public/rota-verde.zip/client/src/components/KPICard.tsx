import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  icon: LucideIcon;
  label: string;
  value: string;
  className?: string;
  sublabel?: string;
  color?: string;
  bgGradient?: string;
}

export function KPICard({ icon: Icon, label, value, className, sublabel, color = "text-primary", bgGradient }: KPICardProps) {
  return (
    <Card 
      className={cn("p-4 relative overflow-hidden", className)} 
      data-testid={`card-${label.toLowerCase().replace(/\s/g, "-")}`}
    >
      {bgGradient && (
        <div className={cn("absolute inset-0 opacity-5", bgGradient)} />
      )}
      <div className="flex flex-col gap-2 relative z-10">
        <div className="flex items-center gap-2">
          <div className={cn("p-2 rounded-lg bg-background/50", color)}>
            <Icon className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            {label}
          </span>
        </div>
        <div className="font-bold text-2xl tabular-nums">{value}</div>
        {sublabel && (
          <div className="text-sm text-muted-foreground">{sublabel}</div>
        )}
      </div>
    </Card>
  );
}
