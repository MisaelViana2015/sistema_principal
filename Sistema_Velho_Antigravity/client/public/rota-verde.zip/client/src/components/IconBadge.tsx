import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface IconBadgeProps {
  icon: LucideIcon;
  color: "green" | "orange" | "blue" | "purple" | "red" | "yellow" | "teal" | "cyan" | "indigo" | "amber";
  size?: "xs" | "sm" | "md" | "lg";
}

export function IconBadge({ icon: Icon, color, size = "md" }: IconBadgeProps) {
  const sizeClasses = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
  };

  const iconSizeClasses = {
    xs: "w-3 h-3",
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  const colorClasses = {
    green: "bg-green-500 shadow-green-500/50",
    orange: "bg-orange-500 shadow-orange-500/50",
    blue: "bg-blue-500 shadow-blue-500/50",
    purple: "bg-purple-500 shadow-purple-500/50",
    red: "bg-red-500 shadow-red-500/50",
    yellow: "bg-yellow-500 shadow-yellow-500/50",
    teal: "bg-teal-500 shadow-teal-500/50",
    cyan: "bg-cyan-500 shadow-cyan-500/50",
    indigo: "bg-indigo-500 shadow-indigo-500/50",
    amber: "bg-amber-500 shadow-amber-500/50",
  };

  return (
    <div
      className={cn(
        "rounded-full flex items-center justify-center shadow-lg",
        sizeClasses[size],
        colorClasses[color]
      )}
    >
      <Icon className={cn("text-white", iconSizeClasses[size])} />
    </div>
  );
}
