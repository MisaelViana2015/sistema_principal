import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatPlate } from "@/lib/format";
import { Star, AlertTriangle, Car, CheckCircle2 } from "lucide-react";
import type { VehicleWithDriver } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";

const startShiftSchema = z.object({
  vehicleId: z.string().min(1, "Selecione um veículo"),
  kmInicial: z.coerce.number().min(0, "KM inicial deve ser maior ou igual a 0"),
});

type StartShiftForm = z.infer<typeof startShiftSchema>;

// 🎨 Extrai a cor do modelo do veículo e retorna classes CSS
function getVehicleColorClasses(modelo: string, isSelected: boolean): string {
  const lastWord = modelo.split(" ").pop()?.toLowerCase() || "";
  
  // Mapeamento de cores
  const colorMap: Record<string, { 
    border: string; 
    borderSelected: string;
    bg: string; 
    bgSelected: string;
    hover: string;
    checkColor: string;
  }> = {
    br: { 
      border: "border-amber-300 dark:border-amber-600",
      borderSelected: "border-amber-500 dark:border-amber-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-amber-100 dark:bg-amber-950",
      hover: "hover:bg-amber-50 dark:hover:bg-amber-950/50",
      checkColor: "text-amber-600 dark:text-amber-400"
    },
    azul: {
      border: "border-blue-300 dark:border-blue-600",
      borderSelected: "border-blue-500 dark:border-blue-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-blue-100 dark:bg-blue-950",
      hover: "hover:bg-blue-50 dark:hover:bg-blue-950/50",
      checkColor: "text-blue-600 dark:text-blue-400"
    },
    pt: {
      border: "border-gray-400 dark:border-gray-500",
      borderSelected: "border-gray-600 dark:border-gray-300",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-gray-200 dark:bg-gray-800",
      hover: "hover:bg-gray-100 dark:hover:bg-gray-800/50",
      checkColor: "text-gray-700 dark:text-gray-300"
    },
  };

  const colors = colorMap[lastWord];
  
  if (!colors) {
    // Cor padrão se não encontrar
    return isSelected 
      ? "border-primary border-4 bg-primary/10" 
      : "border-border border-2";
  }

  if (isSelected) {
    return `${colors.borderSelected} ${colors.bgSelected} border-4`;
  }

  return `${colors.border} ${colors.bg} ${colors.hover} border-2`;
}

// 🎨 Retorna a cor do check mark baseado no modelo
function getCheckColor(modelo: string): string {
  const lastWord = modelo.split(" ").pop()?.toLowerCase() || "";
  
  const colorMap: Record<string, string> = {
    br: "text-amber-600 dark:text-amber-400",
    azul: "text-blue-600 dark:text-blue-400",
    pt: "text-gray-700 dark:text-gray-300",
  };

  return colorMap[lastWord] || "text-primary";
}

export function TurnoInativo() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>("");
  const [showWarning, setShowWarning] = useState(false);
  const [warningMessage, setWarningMessage] = useState("");

  const { data: vehicles = [] } = useQuery<VehicleWithDriver[]>({
    queryKey: ["/api/vehicles"],
    refetchOnMount: "always", // Force fresh data after logout
  });

  const { data: driver } = useQuery({
    queryKey: ["/api/drivers/me"],
    enabled: !!user,
    refetchOnMount: "always", // Force fresh driver data including favorite vehicle
  });

  const form = useForm<StartShiftForm>({
    resolver: zodResolver(startShiftSchema),
    defaultValues: {
      vehicleId: "",
      kmInicial: "" as any,
    },
  });

  // 🔧 Auto-seleciona veículo favorito ao montar o componente
  useEffect(() => {
    if (driver?.veiculoFavoritoId && vehicles.length > 0 && !selectedVehicleId) {
      const favoriteVehicle = vehicles.find(v => v.id === driver.veiculoFavoritoId);
      // Só auto-seleciona se o veículo favorito está disponível
      if (favoriteVehicle && !favoriteVehicle.currentShiftId) {
        setSelectedVehicleId(driver.veiculoFavoritoId);
        form.setValue("vehicleId", driver.veiculoFavoritoId);
      }
    }
  }, [driver, vehicles, selectedVehicleId, form]);

  // 🔧 Mantém o formulário sincronizado com a seleção
  useEffect(() => {
    if (selectedVehicleId) {
      form.setValue("vehicleId", selectedVehicleId);
    }
  }, [selectedVehicleId, form]);

  const startMutation = useMutation({
    mutationFn: (data: StartShiftForm) =>
      apiRequest("POST", "/api/shifts/start", data),
    onSuccess: async () => {
      toast({
        title: "Turno iniciado com sucesso!",
        description: "Seu turno foi registrado e o veículo está em uso.",
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/shifts/active"] });
      await queryClient.refetchQueries({ queryKey: ["/api/shifts/active"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao iniciar turno",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const handleVehicleSelect = (vehicleId: string) => {
    setSelectedVehicleId(vehicleId);
    form.setValue("vehicleId", vehicleId);

    const vehicle = vehicles.find((v) => v.id === vehicleId);
    if (!vehicle) return;

    if (vehicle.motoristaPadraoId && vehicle.motoristaPadraoId !== user?.id) {
      const ownerName = vehicle.motoristaPadrao?.nome || "outro motorista";
      setWarningMessage(`⚠️ Este veículo é do ${ownerName}. Confirmar uso?`);
      setShowWarning(true);
    } else {
      setShowWarning(false);
    }
  };

  const onSubmit = (data: StartShiftForm) => {
    if (!data.vehicleId && selectedVehicleId) {
      data.vehicleId = selectedVehicleId;
    }

    const vehicle = vehicles.find((v) => v.id === data.vehicleId);

    if (vehicle?.currentShiftId) {
      toast({
        title: "Veículo em uso",
        description: `Veículo em uso no turno ${vehicle.currentShiftId}. Escolha outro.`,
        variant: "destructive",
      });
      return;
    }

    startMutation.mutate(data);
  };

  const favoriteVehicle = vehicles.find(
    (v) => v.id === driver?.veiculoFavoritoId,
  );

  return (
    <div className="space-y-6">
      {favoriteVehicle && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              Veículo Favorito
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-md">
              <Car className="w-8 h-8 text-muted-foreground" />
              <div>
                <div className="font-mono text-lg font-bold">
                  {formatPlate(favoriteVehicle.plate)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {favoriteVehicle.modelo}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Iniciar Turno</CardTitle>
          <CardDescription>
            Selecione o veículo e informe o KM inicial
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="vehicleId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base font-semibold">
                      Veículo <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <div className="space-y-3">
                        <input type="hidden" {...field} />
                        <div className="grid gap-3">
                          {vehicles
                            .filter((v) => v.isActive)
                            .sort((a, b) =>
                              a.id === driver?.veiculoFavoritoId
                                ? -1
                                : b.id === driver?.veiculoFavoritoId
                                  ? 1
                                  : 0,
                            )
                            .map((vehicle) => (
                              <button
                                key={vehicle.id}
                                type="button"
                                onClick={() => handleVehicleSelect(vehicle.id)}
                                disabled={!!vehicle.currentShiftId}
                                data-testid={`button-vehicle-${vehicle.id}`}
                                className={`
                                  flex items-center gap-3 p-4 rounded-md transition
                                  ${getVehicleColorClasses(vehicle.modelo, selectedVehicleId === vehicle.id)}
                                  ${vehicle.currentShiftId ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
                                `}
                              >
                                {vehicle.id === driver?.veiculoFavoritoId && (
                                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400 flex-shrink-0" />
                                )}
                                <Car className="w-6 h-6 text-muted-foreground flex-shrink-0" />
                                <div className="flex-1 text-left">
                                  <div className="font-mono font-bold">
                                    {formatPlate(vehicle.plate)}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {vehicle.modelo}
                                  </div>
                                  {vehicle.currentShiftId && (
                                    <div className="text-xs text-destructive mt-1">
                                      Em uso
                                    </div>
                                  )}
                                </div>
                                {selectedVehicleId === vehicle.id && (
                                  <CheckCircle2 className={`w-7 h-7 flex-shrink-0 ${getCheckColor(vehicle.modelo)}`} />
                                )}
                              </button>
                            ))}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {showWarning && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{warningMessage}</AlertDescription>
                </Alert>
              )}

              <FormField
                control={form.control}
                name="kmInicial"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-base font-semibold">
                      KM Inicial <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="Digite o KM inicial"
                        className="text-2xl font-bold"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) =>
                          field.onChange(e.target.value ? parseFloat(e.target.value) : "")
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={startMutation.isPending}
              >
                {startMutation.isPending ? "Iniciando..." : "Iniciar Turno"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
