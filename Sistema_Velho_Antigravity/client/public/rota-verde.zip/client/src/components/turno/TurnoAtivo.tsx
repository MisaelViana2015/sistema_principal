import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { KPICard } from "@/components/KPICard";
import { formatCurrency, formatTime, formatPlate, formatKm } from "@/lib/format";
import { Plus, DollarSign, XCircle, Clock, TrendingDown, TrendingUp, Building2, User, Smartphone, UserCircle, Handshake, Car, MoreHorizontal } from "lucide-react";
import type { ShiftWithDetails, Ride, Cost } from "@shared/schema";
import { IconBadge } from "@/components/IconBadge";

interface TurnoAtivoProps {
  shift: ShiftWithDetails;
}

// Mapeamento de ícones e cores por tipo de custo
const costTypeConfig = {
  "Recarga APP": { icon: Smartphone, color: "blue" as const },
  "Recarga Carro": { icon: Car, color: "orange" as const },
  "Outros": { icon: MoreHorizontal, color: "purple" as const },
};

export function TurnoAtivo({ shift }: TurnoAtivoProps) {
  const [, navigate] = useLocation();
  const [elapsedTime, setElapsedTime] = useState("");

  // Update elapsed time every minute
  useEffect(() => {
    const updateElapsedTime = () => {
      const now = Date.now();
      const start = new Date(shift.inicio).getTime();
      
      // Calculate difference in milliseconds
      const diffMs = now - start;
      
      // Convert to minutes
      const diffMin = Math.floor(diffMs / 60000);
      const hours = Math.floor(diffMin / 60);
      const minutes = diffMin % 60;
      
      // Ensure non-negative values
      const displayHours = Math.max(0, hours);
      const displayMinutes = Math.max(0, minutes);
      
      setElapsedTime(`${displayHours}h ${displayMinutes}min`);
    };

    updateElapsedTime(); // Initial update
    const interval = setInterval(updateElapsedTime, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [shift.inicio]);

  const { data: rides = [] } = useQuery<Ride[]>({
    queryKey: ["/api/rides", shift.id],
    enabled: !!shift?.id,
    refetchInterval: 2000,
    staleTime: 0,
  });

  const { data: costs = [] } = useQuery<Cost[]>({
    queryKey: ["/api/costs", shift.id],
    enabled: !!shift?.id,
    refetchInterval: 2000,
    staleTime: 0,
  });

  // Real-time calculations
  const totalApp = rides
    .filter((r) => r.tipo === "App")
    .reduce((sum, r) => sum + (parseFloat(r.valor as string) || 0), 0);
  const totalParticular = rides
    .filter((r) => r.tipo === "Particular")
    .reduce((sum, r) => sum + (parseFloat(r.valor as string) || 0), 0);
  const totalBruto = totalApp + totalParticular;
  const totalCustos = costs.reduce((sum, c) => sum + (parseFloat(c.valor as string) || 0), 0);
  const liquido = totalBruto - totalCustos;
  const repasseEmpresa = liquido * 0.6;
  const repasseMotorista = liquido * 0.4;
  const corridasApp = rides.filter((r) => r.tipo === "App").length;
  const corridasParticular = rides.filter((r) => r.tipo === "Particular").length;

  return (
    <div className="space-y-6">
      {/* Shift Header */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle>{shift.driver?.nome}</CardTitle>
              <div className="text-sm text-muted-foreground mt-1">
                <span className="font-mono font-bold">{formatPlate(shift.vehicle?.plate || "")}</span>
                {" — "}
                <span>{shift.vehicle?.modelo}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Início</div>
              <div className="font-medium">{formatTime(shift.inicio)}</div>
              <div className="text-sm text-muted-foreground">
                {formatKm(shift.kmInicial)}
              </div>
            </div>
          </div>
          {/* Timer ao Vivo */}
          <div className="mt-4 pt-3 border-t">
            <div className="flex items-center justify-center gap-2 text-primary">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-semibold" data-testid="elapsed-time">
                Tempo Trabalhado: {elapsedTime}
              </span>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-3">
        <Button
          size="lg"
          className="w-full bg-green-600 text-white dark:bg-green-700"
          onClick={() => navigate("/turno/adicionar-corrida")}
          data-testid="button-adicionar-corrida"
        >
          <Plus className="w-5 h-5 mr-2" />
          Adicionar Corrida
        </Button>
        <Button
          size="lg"
          className="w-full bg-red-600 text-white dark:bg-red-700"
          onClick={() => navigate("/turno/adicionar-custo")}
          data-testid="button-adicionar-custo"
        >
          <DollarSign className="w-5 h-5 mr-2" />
          Adicionar Custo
        </Button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <KPICard
          icon={DollarSign}
          label="BRUTO"
          value={formatCurrency(totalBruto)}
          sublabel={`App + Particular`}
          color="text-yellow-600 dark:text-yellow-400"
          bgGradient="bg-gradient-to-br from-yellow-500 to-orange-500"
          className="col-span-2 md:col-span-1"
        />
        <KPICard
          icon={TrendingDown}
          label="DESCONTOS"
          value={formatCurrency(totalCustos)}
          color="text-red-600 dark:text-red-400"
          bgGradient="bg-gradient-to-br from-red-500 to-pink-500"
        />
        <KPICard
          icon={TrendingUp}
          label="LÍQUIDO"
          value={formatCurrency(liquido)}
          color="text-green-600 dark:text-green-400"
          bgGradient="bg-gradient-to-br from-green-500 to-emerald-500"
          className="col-span-2 md:col-span-1"
        />
        <KPICard
          icon={Building2}
          label="EMPRESA (60%)"
          value={formatCurrency(repasseEmpresa)}
          color="text-blue-600 dark:text-blue-400"
          bgGradient="bg-gradient-to-br from-blue-500 to-cyan-500"
          className="col-span-2 md:col-span-1"
        />
        <KPICard
          icon={User}
          label="MOTORISTA (40%)"
          value={formatCurrency(repasseMotorista)}
          color="text-emerald-600 dark:text-emerald-400"
          bgGradient="bg-gradient-to-br from-emerald-500 to-teal-500"
          className="col-span-2 md:col-span-1"
        />
        <KPICard
          icon={Smartphone}
          label="CORRIDAS APP"
          value={`${corridasApp}`}
          sublabel={formatCurrency(totalApp)}
          color="text-indigo-600 dark:text-indigo-400"
          bgGradient="bg-gradient-to-br from-indigo-500 to-blue-500"
        />
        <KPICard
          icon={UserCircle}
          label="CORRIDAS PARTICULAR"
          value={`${corridasParticular}`}
          sublabel={formatCurrency(totalParticular)}
          color="text-amber-600 dark:text-amber-400"
          bgGradient="bg-gradient-to-br from-amber-500 to-yellow-500"
        />
      </div>

      {/* Recent Activity */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Grouped Rides */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Corridas</CardTitle>
          </CardHeader>
          <CardContent>
            {rides.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhuma corrida registrada</p>
            ) : (
              <div className="space-y-4">
                {/* APP Rides */}
                {corridasApp > 0 && (
                  <div className="space-y-2">
                    <div className="font-semibold text-sm flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-blue-500" />
                      APP:
                    </div>
                    {rides
                      .filter(r => r.tipo === "App")
                      .map((ride, idx) => (
                        <div
                          key={ride.id}
                          className="flex items-center justify-between text-sm pl-4"
                          data-testid={`ride-app-${ride.id}`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground font-mono">
                              {idx + 1}
                            </span>
                            <span className="text-muted-foreground">
                              {formatTime(ride.hora)}
                            </span>
                          </div>
                          <span className="font-medium tabular-nums">
                            {formatCurrency(parseFloat(ride.valor as string))}
                          </span>
                        </div>
                      ))}
                    <div className="flex items-center justify-between text-sm font-semibold pl-4 pt-1 border-t">
                      <span>Total de Corridas = {corridasApp}</span>
                      <span className="tabular-nums">Total = {formatCurrency(totalApp)}</span>
                    </div>
                  </div>
                )}

                {/* Particular Rides */}
                {corridasParticular > 0 && (
                  <div className="space-y-2">
                    <div className="font-semibold text-sm flex items-center gap-2">
                      <Handshake className="w-4 h-4 text-green-500" />
                      Particular:
                    </div>
                    {rides
                      .filter(r => r.tipo === "Particular")
                      .map((ride, idx) => (
                        <div
                          key={ride.id}
                          className="flex items-center justify-between text-sm pl-4"
                          data-testid={`ride-particular-${ride.id}`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground font-mono">
                              {idx + 1}
                            </span>
                            <span className="text-muted-foreground">
                              {formatTime(ride.hora)}
                            </span>
                          </div>
                          <span className="font-medium tabular-nums">
                            {formatCurrency(parseFloat(ride.valor as string))}
                          </span>
                        </div>
                      ))}
                    <div className="flex items-center justify-between text-sm font-semibold pl-4 pt-1 border-t">
                      <span>Total de Corridas = {corridasParticular}</span>
                      <span className="tabular-nums">Total = {formatCurrency(totalParticular)}</span>
                    </div>
                  </div>
                )}

                {/* Total Geral APP + Particular */}
                {rides.length > 0 && (
                  <div className="flex items-center justify-between gap-2 text-base font-bold pt-3 border-t-2 border-primary" data-testid="total-geral-corridas">
                    <span>APP + Particular = {corridasApp + corridasParticular} corridas</span>
                    <span className="tabular-nums">{formatCurrency(totalBruto)}</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Costs */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Últimos Custos</CardTitle>
          </CardHeader>
          <CardContent>
            {costs.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum custo registrado</p>
            ) : (
              <div className="space-y-3">
                {costs
                  .slice()
                  .reverse()
                  .slice(0, 5)
                  .map((cost) => {
                    const config = costTypeConfig[cost.tipo as keyof typeof costTypeConfig] || {
                      icon: MoreHorizontal,
                      color: "purple" as const
                    };
                    return (
                      <div
                        key={cost.id}
                        className="flex items-center gap-3 py-2"
                        data-testid={`cost-${cost.id}`}
                      >
                        <IconBadge icon={config.icon} color={config.color} size="sm" />
                        <div className="flex-1 flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{cost.tipo}</span>
                          </div>
                          {cost.observacao && (
                            <span className="text-xs text-muted-foreground">
                              {cost.observacao}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground">
                            {formatTime(cost.hora)}
                          </span>
                        </div>
                        <span className="font-bold tabular-nums text-destructive">
                          {formatCurrency(parseFloat(cost.valor as string))}
                        </span>
                      </div>
                    );
                  })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* End Shift Action */}
      <Button
        size="lg"
        className="w-full bg-black text-white dark:bg-gray-950"
        onClick={() => navigate("/turno/encerrar")}
        data-testid="button-encerrar-turno"
      >
        <XCircle className="w-5 h-5 mr-2" />
        Encerrar Turno
      </Button>
    </div>
  );
}
