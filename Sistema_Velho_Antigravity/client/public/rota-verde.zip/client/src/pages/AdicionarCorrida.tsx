import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRideSchema, type InsertRide } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { TopBar } from "@/components/TopBar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ArrowLeft, Smartphone, Handshake } from "lucide-react";
import type { ShiftWithDetails } from "@shared/schema";

// 🎨 Mapeia tipos de corrida para cores
function getRideTypeColors(tipo: "App" | "Particular", isSelected: boolean): string {
  const colorMap = {
    App: {
      border: "border-yellow-300 dark:border-yellow-600",
      borderSelected: "border-yellow-500 dark:border-yellow-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-yellow-100 dark:bg-yellow-950",
      text: "text-yellow-600 dark:text-yellow-400",
      textSelected: "text-yellow-700 dark:text-yellow-300",
    },
    Particular: {
      border: "border-green-300 dark:border-green-600",
      borderSelected: "border-green-500 dark:border-green-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-green-100 dark:bg-green-950",
      text: "text-green-600 dark:text-green-400",
      textSelected: "text-green-700 dark:text-green-300",
    },
  };

  const colors = colorMap[tipo];
  if (isSelected) {
    return `${colors.borderSelected} ${colors.bgSelected} ${colors.textSelected} border-4`;
  }

  return `${colors.border} ${colors.bg} ${colors.text} border-2`;
}

export default function AdicionarCorrida() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedTipo, setSelectedTipo] = useState<"App" | "Particular" | "">("");

  const { data: activeShift } = useQuery<ShiftWithDetails | null>({
    queryKey: ["/api/shifts/active"],
  });

  const form = useForm<InsertRide>({
    resolver: zodResolver(insertRideSchema),
    defaultValues: {
      shiftId: "",
      tipo: "",
      valor: "",
      hora: new Date(),
    },
  });

  // Update shiftId when activeShift loads
  useEffect(() => {
    if (activeShift?.id) {
      form.setValue("shiftId", activeShift.id);
    }
  }, [activeShift, form]);

  const addRideMutation = useMutation({
    mutationFn: (data: InsertRide) =>
      apiRequest("POST", "/api/rides", data),
    onSuccess: () => {
      toast({
        title: "Corrida registrada!",
        description: "A corrida foi adicionada ao turno atual.",
        duration: 800,
      });
      // Invalidate all rides queries and active shift
      queryClient.invalidateQueries({ queryKey: ["/api/rides"] });
      queryClient.invalidateQueries({ queryKey: ["/api/shifts/active"] });
      navigate("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao registrar corrida",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const handleTipoSelect = (tipo: "App" | "Particular") => {
    setSelectedTipo(tipo);
    form.setValue("tipo", tipo);
  };

  const onSubmit = (data: InsertRide) => {
    if (!activeShift?.id) {
      toast({
        title: "Erro",
        description: "Nenhum turno ativo encontrado",
        variant: "destructive",
      });
      return;
    }

    const submitData: InsertRide = {
      shiftId: activeShift.id,
      tipo: data.tipo,
      valor: data.valor,
      hora: data.hora || new Date(),
    };

    addRideMutation.mutate(submitData);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-2xl mx-auto p-4 space-y-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="gap-2"
            data-testid="button-voltar"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>Adicionar Corrida</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="tipo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">
                          Tipo de Corrida <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <div className="grid grid-cols-2 gap-3">
                            <button
                              type="button"
                              onClick={() => handleTipoSelect("App")}
                              className={`
                                p-6 rounded-md font-semibold text-lg transition-all
                                hover-elevate active-elevate-2 flex flex-col items-center gap-2
                                ${getRideTypeColors("App", selectedTipo === "App")}
                              `}
                              data-testid="button-tipo-app"
                            >
                              <Smartphone className="w-8 h-8" />
                              App
                            </button>
                            <button
                              type="button"
                              onClick={() => handleTipoSelect("Particular")}
                              className={`
                                p-6 rounded-md font-semibold text-lg transition-all
                                hover-elevate active-elevate-2 flex flex-col items-center gap-2
                                ${getRideTypeColors("Particular", selectedTipo === "Particular")}
                              `}
                              data-testid="button-tipo-particular"
                            >
                              <Handshake className="w-8 h-8" />
                              Particular
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="valor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">
                          Valor (R$) <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="Digite o valor"
                            className="text-4xl font-bold tabular-nums h-20"
                            data-testid="input-valor"
                            {...field}
                            onChange={(e) => field.onChange(e.target.value || "")}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={addRideMutation.isPending || !selectedTipo}
                    data-testid="button-salvar-corrida"
                  >
                    {addRideMutation.isPending ? "Salvando..." : "Salvar Corrida"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
