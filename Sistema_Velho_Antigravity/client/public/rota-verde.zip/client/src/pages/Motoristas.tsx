import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { formatPlate } from "@/lib/format";
import { User, Star } from "lucide-react";
import type { DriverWithVehicle, ShiftWithDetails } from "@shared/schema";

export default function Motoristas() {
  const { data: drivers = [], isLoading } = useQuery<DriverWithVehicle[]>({
    queryKey: ["/api/drivers"],
  });

  const { data: activeShifts = [] } = useQuery<ShiftWithDetails[]>({
    queryKey: ["/api/shifts", { status: "em_andamento" }],
  });

  const getDriverStatus = (driverId: string) => {
    return activeShifts.some(s => s.driverId === driverId);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto pb-20 md:pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <h1 className="text-2xl font-bold">Motoristas</h1>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-muted-foreground">Carregando...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {drivers.map((driver) => {
                const isActive = getDriverStatus(driver.id);
                
                return (
                  <Card key={driver.id} data-testid={`driver-${driver.email}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3 flex-1">
                          <User className="w-8 h-8 text-muted-foreground flex-shrink-0" />
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-bold text-lg">{driver.nome}</h3>
                              {driver.role === "admin" && (
                                <Badge variant="default" className="text-xs">Admin</Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{driver.email}</p>
                            {driver.telefone && (
                              <p className="text-sm text-muted-foreground">{driver.telefone}</p>
                            )}
                            {driver.veiculoFavorito && (
                              <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                <span>Favorito: </span>
                                <span className="font-mono font-bold">
                                  {formatPlate(driver.veiculoFavorito.plate)}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 items-end">
                          <Badge
                            variant={isActive ? "default" : "outline"}
                            className="whitespace-nowrap"
                          >
                            {isActive ? "Em Turno" : "Inativo"}
                          </Badge>
                          {!driver.isActive && (
                            <Badge variant="destructive">Desativado</Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
