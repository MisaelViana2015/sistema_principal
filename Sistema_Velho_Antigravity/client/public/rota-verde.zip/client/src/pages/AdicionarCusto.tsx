import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCostSchema, type InsertCost } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { TopBar } from "@/components/TopBar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ArrowLeft, Smartphone, Car, MoreHorizontal } from "lucide-react";
import type { ShiftWithDetails } from "@shared/schema";
import { IconBadge } from "@/components/IconBadge";

const costTypes = ["Recarga APP", "Recarga Carro", "Outros"];

// Mapeamento de ícones por tipo
const costTypeIcons = {
  "Recarga APP": Smartphone,
  "Recarga Carro": Car,
  "Outros": MoreHorizontal,
};

// Mapeamento de cores para IconBadge
const costTypeIconColors = {
  "Recarga APP": "blue" as const,
  "Recarga Carro": "orange" as const,
  "Outros": "purple" as const,
};

// 🎨 Mapeia tipos de custo para cores
function getCostTypeColors(tipo: string, isSelected: boolean): string {
  const colorMap: Record<string, { border: string; borderSelected: string; bg: string; bgSelected: string; text: string; textSelected: string }> = {
    "Recarga APP": {
      border: "border-blue-300 dark:border-blue-600",
      borderSelected: "border-blue-500 dark:border-blue-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-blue-100 dark:bg-blue-950",
      text: "text-blue-600 dark:text-blue-400",
      textSelected: "text-blue-700 dark:text-blue-300",
    },
    "Recarga Carro": {
      border: "border-orange-300 dark:border-orange-600",
      borderSelected: "border-orange-500 dark:border-orange-400",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-orange-100 dark:bg-orange-950",
      text: "text-orange-600 dark:text-orange-400",
      textSelected: "text-orange-700 dark:text-orange-300",
    },
    "Outros": {
      border: "border-gray-400 dark:border-gray-500",
      borderSelected: "border-gray-600 dark:border-gray-300",
      bg: "bg-white dark:bg-background",
      bgSelected: "bg-gray-200 dark:bg-gray-800",
      text: "text-gray-600 dark:text-gray-400",
      textSelected: "text-gray-700 dark:text-gray-300",
    },
  };

  const colors = colorMap[tipo];
  if (!colors) {
    return isSelected ? "border-primary border-4 bg-primary/10" : "border-border border-2";
  }

  if (isSelected) {
    return `${colors.borderSelected} ${colors.bgSelected} ${colors.textSelected} border-4`;
  }

  return `${colors.border} ${colors.bg} ${colors.text} border-2`;
}

export default function AdicionarCusto() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedTipo, setSelectedTipo] = useState<string>("");

  const { data: activeShift } = useQuery<ShiftWithDetails | null>({
    queryKey: ["/api/shifts/active"],
  });

  const form = useForm<InsertCost>({
    resolver: zodResolver(insertCostSchema),
    defaultValues: {
      shiftId: "",
      tipo: "",
      valor: "",
      observacao: "",
      hora: new Date(),
    },
  });

  // Update shiftId when activeShift loads
  useEffect(() => {
    if (activeShift?.id) {
      form.setValue("shiftId", activeShift.id);
    }
  }, [activeShift, form]);

  const addCostMutation = useMutation({
    mutationFn: (data: InsertCost) =>
      apiRequest("POST", "/api/costs", data),
    onSuccess: () => {
      toast({
        title: "Custo registrado!",
        description: "O custo foi adicionado ao turno atual.",
        duration: 800,
      });
      // Invalidate all costs queries and active shift
      queryClient.invalidateQueries({ queryKey: ["/api/costs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/shifts/active"] });
      navigate("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao registrar custo",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const handleTipoSelect = (tipo: string) => {
    setSelectedTipo(tipo);
    form.setValue("tipo", tipo);
  };

  const onSubmit = (data: InsertCost) => {
    if (!activeShift?.id) {
      toast({
        title: "Erro",
        description: "Nenhum turno ativo encontrado",
        variant: "destructive",
      });
      return;
    }

    const submitData: InsertCost = {
      shiftId: activeShift.id,
      tipo: data.tipo,
      valor: data.valor,
      observacao: data.observacao || null,
      hora: data.hora || new Date(),
    };

    addCostMutation.mutate(submitData);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto">
        <div className="max-w-2xl mx-auto p-4 space-y-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="gap-2"
            data-testid="button-voltar"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>Adicionar Custo</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="tipo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">
                          Tipo de Custo <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <div className="grid gap-3">
                            {costTypes.map((tipo) => {
                              const Icon = costTypeIcons[tipo as keyof typeof costTypeIcons];
                              const iconColor = costTypeIconColors[tipo as keyof typeof costTypeIconColors];
                              return (
                                <button
                                  key={tipo}
                                  type="button"
                                  onClick={() => handleTipoSelect(tipo)}
                                  className={`
                                    p-4 rounded-md font-semibold transition-all
                                    hover-elevate active-elevate-2 flex items-center gap-3
                                    ${getCostTypeColors(tipo, selectedTipo === tipo)}
                                  `}
                                  data-testid={`button-tipo-${tipo.toLowerCase().replace(/\s/g, "-")}`}
                                >
                                  {Icon && <IconBadge icon={Icon} color={iconColor} size="md" />}
                                  <span>{tipo}</span>
                                </button>
                              );
                            })}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="valor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base font-semibold">
                          Valor (R$) <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="Digite o valor"
                            className="text-4xl font-bold tabular-nums h-20"
                            data-testid="input-valor"
                            {...field}
                            onChange={(e) => field.onChange(e.target.value || "")}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="observacao"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Observação (opcional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Detalhes adicionais..."
                            data-testid="input-observacao"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={addCostMutation.isPending || !selectedTipo}
                    data-testid="button-salvar-custo"
                  >
                    {addCostMutation.isPending ? "Salvando..." : "Salvar Custo"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
