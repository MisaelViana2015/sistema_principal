import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { formatDateTime } from "@/lib/format";
import { useAuth } from "@/contexts/AuthContext";
import type { LogWithUser, Driver } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

export default function Logs() {
  const { isAdmin } = useAuth();
  const [selectedDriverId, setSelectedDriverId] = useState<string>("todos");
  const [selectedAcao, setSelectedAcao] = useState<string>("todas");

  const { data: logs = [], isLoading } = useQuery<LogWithUser[]>({
    queryKey: ["/api/logs", { 
      driverId: selectedDriverId !== "todos" ? selectedDriverId : undefined,
      acao: selectedAcao !== "todas" ? selectedAcao : undefined 
    }],
  });

  const { data: drivers = [] } = useQuery<Driver[]>({
    queryKey: ["/api/drivers"],
    enabled: isAdmin,
  });

  const acoes = Array.from(new Set(logs.map(l => l.acao)));

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto pb-20 md:pb-8">
        <div className="max-w-7xl mx-auto p-4 space-y-6">
          <h1 className="text-2xl font-bold">Logs de Auditoria</h1>

          {/* Filters */}
          {isAdmin && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-wrap gap-4">
                  <div className="flex-1 min-w-[200px]">
                    <label className="text-sm font-medium mb-2 block">Motorista</label>
                    <Select value={selectedDriverId} onValueChange={setSelectedDriverId}>
                      <SelectTrigger data-testid="select-motorista">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos</SelectItem>
                        {drivers.map(driver => (
                          <SelectItem key={driver.id} value={driver.id}>
                            {driver.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex-1 min-w-[200px]">
                    <label className="text-sm font-medium mb-2 block">Ação</label>
                    <Select value={selectedAcao} onValueChange={setSelectedAcao}>
                      <SelectTrigger data-testid="select-acao">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todas">Todas</SelectItem>
                        {acoes.map(acao => (
                          <SelectItem key={acao} value={acao}>
                            {acao}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Logs List */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Histórico de Ações</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="text-muted-foreground">Carregando...</div>
                </div>
              ) : logs.length === 0 ? (
                <p className="text-center py-12 text-muted-foreground">
                  Nenhum log encontrado
                </p>
              ) : (
                <div className="space-y-2">
                  {logs.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-center justify-between p-4 border rounded-md hover:bg-muted/50"
                      data-testid={`log-${log.id}`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <span className="text-sm text-muted-foreground">
                            {formatDateTime(log.data)}
                          </span>
                          <span className="font-medium">{log.user?.nome}</span>
                        </div>
                        <div className="text-sm">
                          <span className="font-semibold">{log.acao}</span>
                          {" • "}
                          <span className="text-muted-foreground">{log.entidade}</span>
                          {" • "}
                          <span className="text-muted-foreground font-mono text-xs">
                            ID: {log.referenciaId}
                          </span>
                        </div>
                      </div>
                      {log.payload && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-2"
                              data-testid={`button-ver-payload-${log.id}`}
                            >
                              <Eye className="w-4 h-4" />
                              Ver
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
                            <DialogHeader>
                              <DialogTitle>Detalhes da Ação</DialogTitle>
                              <DialogDescription>
                                {log.acao} • {formatDateTime(log.data)}
                              </DialogDescription>
                            </DialogHeader>
                            <pre className="bg-muted p-4 rounded-md overflow-auto text-xs">
                              {JSON.stringify(log.payload, null, 2)}
                            </pre>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
