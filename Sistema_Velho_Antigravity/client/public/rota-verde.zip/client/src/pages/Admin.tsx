import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDriverSchema, insertVehicleSchema, type InsertDriver, type InsertVehicle, type Driver, type Vehicle } from "@shared/schema";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TopBar } from "@/components/TopBar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

const driverFormSchema = insertDriverSchema.extend({
  senha: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
});

export default function Admin() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("motoristas");

  const { data: drivers = [] } = useQuery<Driver[]>({
    queryKey: ["/api/drivers"],
  });

  const { data: vehicles = [] } = useQuery<Vehicle[]>({
    queryKey: ["/api/vehicles"],
  });

  // Driver form
  const driverForm = useForm<InsertDriver & { senha: string }>({
    resolver: zodResolver(driverFormSchema),
    defaultValues: {
      nome: "",
      email: "",
      senha: "",
      telefone: "",
      veiculoFavoritoId: null,
      role: "driver",
      isActive: true,
    },
  });

  // Vehicle form
  const vehicleForm = useForm<InsertVehicle>({
    resolver: zodResolver(insertVehicleSchema),
    defaultValues: {
      plate: "",
      modelo: "",
      motoristaPadraoId: null,
      isActive: true,
    },
  });

  const createDriverMutation = useMutation({
    mutationFn: (data: InsertDriver & { senha: string }) =>
      apiRequest("POST", "/api/drivers", data),
    onSuccess: () => {
      toast({
        title: "Motorista criado!",
        description: "Novo motorista adicionado ao sistema.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/drivers"] });
      driverForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar motorista",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const createVehicleMutation = useMutation({
    mutationFn: (data: InsertVehicle) =>
      apiRequest("POST", "/api/vehicles", data),
    onSuccess: () => {
      toast({
        title: "Veículo criado!",
        description: "Novo veículo adicionado à frota.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      vehicleForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar veículo",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
              className="gap-2"
              data-testid="button-voltar"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold">Área Administrativa</h1>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="motoristas" data-testid="tab-motoristas">
                Motoristas
              </TabsTrigger>
              <TabsTrigger value="veiculos" data-testid="tab-veiculos">
                Veículos
              </TabsTrigger>
            </TabsList>

            <TabsContent value="motoristas" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Cadastrar Motorista</CardTitle>
                  <CardDescription>
                    Adicione um novo motorista ao sistema
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...driverForm}>
                    <form
                      onSubmit={driverForm.handleSubmit((data) =>
                        createDriverMutation.mutate(data)
                      )}
                      className="space-y-4"
                    >
                      <FormField
                        control={driverForm.control}
                        name="nome"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Nome completo"
                                data-testid="input-driver-nome"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={driverForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="email@example.com"
                                data-testid="input-driver-email"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={driverForm.control}
                        name="senha"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Senha</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                data-testid="input-driver-senha"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={driverForm.control}
                        name="telefone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefone (opcional)</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="(00) 00000-0000"
                                data-testid="input-driver-telefone"
                                {...field}
                                value={field.value || ""}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={driverForm.control}
                        name="veiculoFavoritoId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Veículo Favorito (opcional)</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(value || null)}
                              value={field.value || undefined}
                            >
                              <FormControl>
                                <SelectTrigger data-testid="select-driver-veiculo">
                                  <SelectValue placeholder="Nenhum" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {vehicles.map((v) => (
                                  <SelectItem key={v.id} value={v.id}>
                                    {v.plate} - {v.modelo}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={driverForm.control}
                        name="role"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Perfil</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-driver-role">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="driver">Motorista</SelectItem>
                                <SelectItem value="admin">Administrador</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        className="w-full"
                        disabled={createDriverMutation.isPending}
                        data-testid="button-criar-motorista"
                      >
                        {createDriverMutation.isPending
                          ? "Criando..."
                          : "Criar Motorista"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="veiculos" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Cadastrar Veículo</CardTitle>
                  <CardDescription>
                    Adicione um novo veículo à frota
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...vehicleForm}>
                    <form
                      onSubmit={vehicleForm.handleSubmit((data) =>
                        createVehicleMutation.mutate(data)
                      )}
                      className="space-y-4"
                    >
                      <FormField
                        control={vehicleForm.control}
                        name="plate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Placa</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="TQQ0A07"
                                className="font-mono uppercase"
                                data-testid="input-vehicle-plate"
                                {...field}
                                onChange={(e) =>
                                  field.onChange(e.target.value.toUpperCase())
                                }
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={vehicleForm.control}
                        name="modelo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Modelo</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Dolphi Mini Azul"
                                data-testid="input-vehicle-modelo"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={vehicleForm.control}
                        name="motoristaPadraoId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Motorista Padrão (opcional)</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(value || null)}
                              value={field.value || undefined}
                            >
                              <FormControl>
                                <SelectTrigger data-testid="select-vehicle-motorista">
                                  <SelectValue placeholder="Nenhum" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {drivers.map((d) => (
                                  <SelectItem key={d.id} value={d.id}>
                                    {d.nome}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        className="w-full"
                        disabled={createVehicleMutation.isPending}
                        data-testid="button-criar-veiculo"
                      >
                        {createVehicleMutation.isPending
                          ? "Criando..."
                          : "Criar Veículo"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
