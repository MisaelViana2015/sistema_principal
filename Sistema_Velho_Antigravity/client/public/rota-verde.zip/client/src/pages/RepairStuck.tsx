import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatPlate } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";

type Vehicle = { id: string; plate: string; modelo: string; currentShiftId?: string | null };
type Shift = { id: string; driverId: string; vehicleId: string; status: string; inicio: string };

export default function RepairStuck() {
  const toast = useToast();

  const { data: vehicles = [], refetch: refetchVehicles } = useQuery<Vehicle[]>({
    queryKey: ["/api/vehicles/locked"],
    queryFn: async () => {
      const r = await fetch("/api/vehicles/locked");
      if (!r.ok) throw new Error("Erro ao buscar veículos");
      return r.json();
    },
  });

  const { data: activeShifts = [], refetch: refetchShifts } = useQuery<Shift[]>({
    queryKey: ["/api/shifts/all-active"],
    queryFn: async () => {
      const r = await fetch("/api/shifts");
      if (!r.ok) throw new Error("Erro ao buscar turnos");
      return r.json();
    },
  });

  const repair = useMutation(
    async () => {
      const r = await fetch("/api/shifts/repair-stuck", { method: "POST" });
      if (!r.ok) throw new Error(await r.text());
      return r.json();
    },
    {
      onSuccess: (data) => {
        toast.success("Reparo executado");
        refetchVehicles();
        refetchShifts();
        toast.info(JSON.stringify(data, null, 2).slice(0, 200));
      },
      onError: (err: any) => toast.error(String(err)),
    },
  );

  const forceEnd = useMutation(
    async (shiftId: string) => {
      const r = await fetch("/api/shifts/force-end", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shiftId, motivo: "Encerramento via admin UI" }),
      });
      if (!r.ok) throw new Error(await r.text());
      return r.json();
    },
    {
      onSuccess: () => {
        toast.success("Turno encerrado forçosamente");
        refetchVehicles();
        refetchShifts();
      },
      onError: (err: any) => toast.error(String(err)),
    },
  );

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      <main className="flex-1 pb-20 md:pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <h1 className="text-2xl font-bold">Admin — Reparar veículos travados</h1>

          <Card>
            <CardHeader>
              <CardTitle>Veículos bloqueados (currentShiftId)</CardTitle>
            </CardHeader>
            <CardContent>
              {vehicles.length === 0 ? (
                <div className="text-sm text-muted-foreground">Nenhum veículo bloqueado</div>
              ) : (
                <div className="space-y-2">
                  {vehicles.map(v => (
                    <div key={v.id} className="p-3 border rounded">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-mono font-bold">{formatPlate(v.plate)}</div>
                          <div className="text-sm text-muted-foreground">{v.modelo}</div>
                          <div className="text-xs text-muted-foreground">ShiftId: {String(v.currentShiftId)}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-4">
                <Button onClick={() => repair.mutate()} disabled={repair.isLoading}>
                  {repair.isLoading ? "Executando..." : "Repair stuck (limpar veículos inconsistente)"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Turnos em andamento</CardTitle>
            </CardHeader>
            <CardContent>
              {activeShifts.length === 0 ? (
                <div className="text-sm text-muted-foreground">Nenhum turno em andamento</div>
              ) : (
                <div className="space-y-2">
                  {activeShifts.map(s => (
                    <div key={s.id} className="p-3 border rounded flex justify-between items-center">
                      <div>
                        <div className="font-bold">Turno {s.id}</div>
                        <div className="text-sm text-muted-foreground">Veículo: {s.vehicleId} • Motorista: {s.driverId}</div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="destructive" onClick={() => forceEnd.mutate(s.id)}>
                          Forçar Encerramento
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
