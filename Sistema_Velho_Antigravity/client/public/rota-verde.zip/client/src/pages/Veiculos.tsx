import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { formatPlate } from "@/lib/format";
import { Star, Car } from "lucide-react";
import type { VehicleWithDriver } from "@shared/schema";

// Function to get vehicle color based on model
// Matches specific model names to avoid false positives
function getVehicleColor(modelo: string) {
  const modeloLower = modelo.toLowerCase().trim();
  
  // Check for "Azul" models (e.g., "Dolphi Mini Azul")
  if (modeloLower.includes("azul")) {
    return {
      iconColor: "text-blue-500",
      borderColor: "border-l-blue-500",
      bgGradient: "from-blue-500/10 to-blue-500/5"
    };
  }
  
  // Check for "BR" models - must be word boundary or end of string
  // Matches: "Mini BR", "Dolphi BR" but NOT "Branco"
  if (/\bbr\b/i.test(modeloLower) || modeloLower.endsWith(" br")) {
    return {
      iconColor: "text-amber-500",
      borderColor: "border-l-amber-500",
      bgGradient: "from-amber-500/10 to-amber-500/5"
    };
  }
  
  // Check for "PT" models - must be word boundary or end of string
  // Matches: "Mini PT", "Dolphi PT"
  if (/\bpt\b/i.test(modeloLower) || modeloLower.endsWith(" pt")) {
    return {
      iconColor: "text-gray-500",
      borderColor: "border-l-gray-500",
      bgGradient: "from-gray-500/10 to-gray-500/5"
    };
  }
  
  // Default color for unknown models
  return {
    iconColor: "text-muted-foreground",
    borderColor: "border-l-muted-foreground",
    bgGradient: "from-muted/50 to-muted/10"
  };
}

export default function Veiculos() {
  const { data: vehicles = [], isLoading } = useQuery<VehicleWithDriver[]>({
    queryKey: ["/api/vehicles"],
    refetchOnMount: "always", // Force refetch to prevent stale cache after logout
  });

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto pb-20 md:pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <h1 className="text-2xl font-bold">Veículos</h1>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-muted-foreground">Carregando...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {vehicles.map((vehicle) => {
                const colors = getVehicleColor(vehicle.modelo);
                return (
                <Card 
                  key={vehicle.id} 
                  data-testid={`vehicle-${vehicle.plate}`}
                  className={`border-l-4 ${colors.borderColor} bg-gradient-to-r ${colors.bgGradient}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3 flex-1">
                        <Car className={`w-8 h-8 ${colors.iconColor} flex-shrink-0`} />
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-mono text-lg font-bold">
                              {formatPlate(vehicle.plate)}
                            </h3>
                            {vehicle.motoristaPadrao && (
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{vehicle.modelo}</p>
                          {vehicle.motoristaPadrao && (
                            <p className="text-sm text-muted-foreground mt-1">
                              Motorista padrão: {vehicle.motoristaPadrao.nome}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 items-end">
                        <Badge
                          variant={vehicle.currentShiftId ? "destructive" : "default"}
                          className="whitespace-nowrap"
                        >
                          {vehicle.currentShiftId ? "Em Uso" : "Disponível"}
                        </Badge>
                        {!vehicle.isActive && (
                          <Badge variant="outline">Inativo</Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
              })}
            </div>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
