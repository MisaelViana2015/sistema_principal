import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { TopBar } from "@/components/TopBar";
import { BottomNav } from "@/components/BottomNav";
import { TurnoInativo } from "@/components/turno/TurnoInativo";
import { TurnoAtivo } from "@/components/turno/TurnoAtivo";
import type { ShiftWithDetails } from "@shared/schema";

export default function Turno() {
  const { user } = useAuth();

  const { data: activeShift, isLoading } = useQuery<ShiftWithDetails | null>({
    queryKey: ["/api/shifts/active"],
    enabled: !!user,
    refetchInterval: 2000, // refetch a cada 2s para garantir sincronia
    staleTime: 0, // sempre considera dados como "velhos"
  });

  // regra principal: só considera turno “ativo” se tiver veículo e km inicial definidos
  const hasValidShift =
    activeShift &&
    activeShift.vehicleId &&
    activeShift.kmInicial !== null &&
    activeShift.kmInicial !== undefined;

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />

      <main className="flex-1 overflow-auto pb-20 md:pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-muted-foreground">Carregando...</div>
            </div>
          ) : hasValidShift ? (
            <TurnoAtivo shift={activeShift!} />
          ) : (
            <TurnoInativo />
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
