import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { TopBar } from "@/components/TopBar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatTime, formatDate, formatKm, formatDuration, formatPlate } from "@/lib/format";
import { calculateShiftTotals } from "@/lib/calc";
import { ArrowLeft, Smartphone, Handshake, DollarSign, TrendingDown, TrendingUp, Building2, User, Gauge, Coins, Car, Receipt } from "lucide-react";
import { IconBadge } from "@/components/IconBadge";
import type { ShiftWithDetails, Ride, Cost } from "@shared/schema";

const endShiftSchema = z.object({
  kmFinal: z.union([z.string(), z.number()]).refine(
    (val) => {
      if (val === "") return false; // Empty string is invalid for submission
      const num = typeof val === "string" ? parseFloat(val) : val;
      return !isNaN(num) && num >= 0;
    },
    { message: "KM final deve ser maior ou igual a 0" }
  ),
});

type EndShiftForm = z.infer<typeof endShiftSchema>;

export default function EncerrarTurno() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: activeShift } = useQuery<ShiftWithDetails | null>({
    queryKey: ["/api/shifts/active"],
  });

  const { data: rides = [] } = useQuery<Ride[]>({
    queryKey: ["/api/rides", activeShift?.id],
    enabled: !!activeShift?.id,
    refetchInterval: 2000,
    staleTime: 0,
  });

  const { data: costs = [] } = useQuery<Cost[]>({
    queryKey: ["/api/costs", activeShift?.id],
    enabled: !!activeShift?.id,
    refetchInterval: 2000,
    staleTime: 0,
  });

  const form = useForm<EndShiftForm>({
    resolver: zodResolver(endShiftSchema),
    defaultValues: {
      kmFinal: undefined as any,
    },
  });

  const kmFinal = form.watch("kmFinal");
  const kmFinalNum = kmFinal === "" || kmFinal == null ? null : typeof kmFinal === "string" ? parseFloat(kmFinal) : kmFinal;
  const calculations = activeShift && kmFinalNum != null && !isNaN(kmFinalNum) && kmFinalNum >= activeShift.kmInicial
    ? calculateShiftTotals(
        rides,
        costs,
        activeShift.kmInicial,
        kmFinalNum,
        new Date(activeShift.inicio),
        new Date()
      )
    : null;

  const endShiftMutation = useMutation({
    mutationFn: (data: EndShiftForm) => {
      const kmFinalValue = typeof data.kmFinal === "string" ? parseFloat(data.kmFinal) : data.kmFinal;
      return apiRequest("POST", "/api/shifts/end", {
        shiftId: activeShift?.id,
        kmFinal: kmFinalValue,
      });
    },
    onSuccess: () => {
      toast({
        title: "Turno encerrado!",
        description: "Resumo salvo e veículo liberado.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/shifts/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      navigate("/");
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao encerrar turno",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EndShiftForm) => {
    if (!activeShift) return;

    const kmFinalValue = typeof data.kmFinal === "string" ? parseFloat(data.kmFinal) : data.kmFinal;
    
    if (kmFinalValue < activeShift.kmInicial) {
      toast({
        title: "KM inválido",
        description: "KM final não pode ser menor que o inicial.",
        variant: "destructive",
      });
      return;
    }

    endShiftMutation.mutate(data);
  };

  if (!activeShift) {
    return (
      <div className="flex flex-col min-h-screen bg-background">
        <TopBar />
        <main className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Nenhum turno ativo encontrado</p>
        </main>
      </div>
    );
  }

  const ridesApp = rides.filter((r) => r.tipo === "App");
  const ridesParticular = rides.filter((r) => r.tipo === "Particular");

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <TopBar />
      
      <main className="flex-1 overflow-auto pb-8">
        <div className="max-w-4xl mx-auto p-4 space-y-6">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="gap-2"
            data-testid="button-voltar"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>

          {/* Header */}
          <Card>
            <CardHeader>
              <CardTitle>Encerramento de Turno</CardTitle>
              <div className="text-sm text-muted-foreground mt-2">
                <div><strong>Motorista:</strong> {activeShift.driver?.nome}</div>
                <div className="flex items-center gap-2 mt-1">
                  <strong className="font-mono">{formatPlate(activeShift.vehicle?.plate || "")}</strong>
                  <span>—</span>
                  <span>{activeShift.vehicle?.modelo}</span>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Corridas App */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-3">
                <IconBadge icon={Smartphone} color="blue" size="md" />
                Aplicativo
              </CardTitle>
            </CardHeader>
            <CardContent>
              {ridesApp.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhuma corrida por app</p>
              ) : (
                <div className="space-y-2 font-mono text-sm">
                  {ridesApp.map((ride, idx) => (
                    <div key={ride.id} className="flex justify-between">
                      <span className="text-muted-foreground">
                        {idx + 1} - {formatTime(ride.hora)}
                      </span>
                      <span className="font-bold">{formatCurrency(parseFloat(ride.valor as string))}</span>
                    </div>
                  ))}
                  <Separator className="my-3" />
                  <div className="flex justify-between font-bold">
                    <span>Total APP</span>
                    <span>{formatCurrency(calculations?.totalApp || 0)}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Total Corridas APP</span>
                    <span>{ridesApp.length}</span>
                  </div>
                  {calculations && calculations.ticketMedioApp > 0 && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <IconBadge icon={Receipt} color="blue" size="xs" />
                        <span className="text-sm text-muted-foreground">Ticket Médio APP</span>
                      </div>
                      <span className="font-mono">{formatCurrency(calculations.ticketMedioApp)}</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Corridas Particular */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-3">
                <IconBadge icon={Handshake} color="green" size="md" />
                Particular
              </CardTitle>
            </CardHeader>
            <CardContent>
              {ridesParticular.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhuma corrida particular</p>
              ) : (
                <div className="space-y-2 font-mono text-sm">
                  {ridesParticular.map((ride, idx) => (
                    <div key={ride.id} className="flex justify-between">
                      <span className="text-muted-foreground">
                        {idx + 1} - {formatTime(ride.hora)}
                      </span>
                      <span className="font-bold">{formatCurrency(parseFloat(ride.valor as string))}</span>
                    </div>
                  ))}
                  <Separator className="my-3" />
                  <div className="flex justify-between font-bold">
                    <span>Total Particular</span>
                    <span>{formatCurrency(calculations?.totalParticular || 0)}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Total Corridas Particulares</span>
                    <span>{ridesParticular.length}</span>
                  </div>
                  {calculations && calculations.ticketMedioParticular > 0 && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <IconBadge icon={Receipt} color="green" size="xs" />
                        <span className="text-sm text-muted-foreground">Ticket Médio Particular</span>
                      </div>
                      <span className="font-mono">{formatCurrency(calculations.ticketMedioParticular)}</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Resumo Financeiro */}
          {calculations && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Resumo Financeiro</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <IconBadge icon={DollarSign} color="yellow" size="md" />
                      <span className="font-mono text-sm">Receita Total</span>
                    </div>
                    <span className="font-mono font-bold text-lg">{formatCurrency(calculations.totalBruto)}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <IconBadge icon={TrendingDown} color="red" size="md" />
                      <span className="font-mono text-sm">Custos</span>
                    </div>
                    <span className="font-mono font-bold text-lg text-destructive">{formatCurrency(calculations.totalCustos)}</span>
                  </div>
                  
                  <Separator className="my-3" />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <IconBadge icon={TrendingUp} color="green" size="md" />
                      <span className="font-mono font-semibold">Lucro Líquido</span>
                    </div>
                    <span className="font-mono font-bold text-xl text-primary">{formatCurrency(calculations.liquido)}</span>
                  </div>
                  
                  <Separator className="my-3" />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <IconBadge icon={Building2} color="blue" size="md" />
                      <span className="font-mono text-sm">Empresa (60%)</span>
                    </div>
                    <span className="font-mono font-bold text-lg">{formatCurrency(calculations.repasseEmpresa)}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <IconBadge icon={User} color="teal" size="md" />
                      <span className="font-mono text-sm">Motorista (40%)</span>
                    </div>
                    <span className="font-mono font-bold text-lg">{formatCurrency(calculations.repasseMotorista)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Dados Operacionais */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Dados Operacionais</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">KM Inicial</label>
                      <div className="text-2xl font-bold tabular-nums mt-1">
                        {activeShift.kmInicial.toFixed(1)}
                      </div>
                    </div>
                    <FormField
                      control={form.control}
                      name="kmFinal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="font-semibold">
                            KM Final <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.1"
                              placeholder="Digite o KM final"
                              className="text-2xl font-bold tabular-nums"
                              data-testid="input-km-final"
                              {...field}
                              value={field.value === "" || field.value == null ? "" : field.value}
                              onChange={(e) => {
                                const val = e.target.value;
                                field.onChange(val === "" ? "" : Number(val));
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {calculations && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <IconBadge icon={Gauge} color="indigo" size="sm" />
                          <span className="font-mono text-sm">KM Rodados</span>
                        </div>
                        <span className="font-mono font-bold">{formatKm(calculations.kmRodado)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <IconBadge icon={Coins} color="amber" size="sm" />
                          <span className="font-mono text-sm">Valor por KM</span>
                        </div>
                        <span className="font-mono font-bold">{formatCurrency(calculations.valorKm)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <IconBadge icon={Car} color="purple" size="sm" />
                          <span className="font-mono text-sm">Total de Corridas</span>
                        </div>
                        <span className="font-mono font-bold">{calculations.totalCorridas}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <IconBadge icon={Receipt} color="cyan" size="sm" />
                          <span className="font-mono text-sm">Ticket Médio Geral</span>
                        </div>
                        <span className="font-mono font-bold">{formatCurrency(calculations.ticketMedioGeral)}</span>
                      </div>
                      <div className="flex justify-between font-mono text-sm">
                        <span className="text-muted-foreground">Início</span>
                        <span className="font-bold">{formatTime(activeShift.inicio)}</span>
                      </div>
                      <div className="flex justify-between font-mono text-sm">
                        <span className="text-muted-foreground">Duração do Turno</span>
                        <span className="font-bold">{formatDuration(calculations.duracaoMin)}</span>
                      </div>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    variant="destructive"
                    disabled={endShiftMutation.isPending || !calculations}
                    data-testid="button-confirmar-encerramento"
                  >
                    {endShiftMutation.isPending ? "Encerrando..." : "Confirmar Fechamento"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
