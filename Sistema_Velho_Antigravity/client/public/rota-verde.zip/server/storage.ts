import { randomUUID } from "crypto";
import { db } from "./db";
import {
  drivers,
  vehicles,
  shifts,
  rides,
  costs,
  logs,
  type Driver,
  type InsertDriver,
  type Vehicle,
  type InsertVehicle,
  type Shift,
  type InsertShift,
  type Ride,
  type InsertRide,
  type Cost,
  type InsertCost,
  type Log,
  type InsertLog,
  type DriverWithVehicle,
  type VehicleWithDriver,
  type ShiftWithDetails,
  type LogWithUser,
} from "@shared/schema";
import { eq, and, gte, lte, isNull } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // Drivers
  getDriver(id: string): Promise<Driver | undefined>;
  getDriverByEmail(email: string): Promise<Driver | undefined>;
  getDriverWithVehicle(id: string): Promise<DriverWithVehicle | undefined>;
  getAllDrivers(): Promise<Driver[]>;
  getAllDriversWithVehicles(): Promise<DriverWithVehicle[]>;
  createDriver(driver: InsertDriver): Promise<Driver>;
  updateDriver(id: string, driver: Partial<Driver>): Promise<Driver | undefined>;

  // Vehicles
  getVehicle(id: string): Promise<Vehicle | undefined>;
  getVehicleWithDriver(id: string): Promise<VehicleWithDriver | undefined>;
  getAllVehicles(): Promise<Vehicle[]>;
  getAllVehiclesWithDrivers(): Promise<VehicleWithDriver[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: string, vehicle: Partial<Vehicle>): Promise<Vehicle | undefined>;
  cleanOrphanVehicles(): Promise<number>;

  // Shifts
  getShift(id: string): Promise<Shift | undefined>;
  getShiftWithDetails(id: string): Promise<ShiftWithDetails | undefined>;
  getActiveShiftByDriver(driverId: string): Promise<ShiftWithDetails | null>;
  getAllShifts(filters?: {
    driverId?: string;
    status?: string;
    from?: Date;
    to?: Date;
  }): Promise<ShiftWithDetails[]>;
  createShift(shift: InsertShift): Promise<Shift>;
  updateShift(id: string, shift: Partial<Shift>): Promise<Shift | undefined>;

  // Rides
  getRidesByShift(shiftId: string): Promise<Ride[]>;
  createRide(ride: InsertRide): Promise<Ride>;

  // Costs
  getCostsByShift(shiftId: string): Promise<Cost[]>;
  createCost(cost: InsertCost): Promise<Cost>;

  // Logs
  getAllLogs(filters?: {
    userId?: string;
    acao?: string;
    entidade?: string;
    from?: Date;
    to?: Date;
  }): Promise<LogWithUser[]>;
  createLog(log: InsertLog): Promise<Log>;
}

// Database storage implementation using Drizzle ORM
export class DatabaseStorage implements IStorage {

  // Drivers
  async getDriver(id: string): Promise<Driver | undefined> {
    const [driver] = await db.select().from(drivers).where(eq(drivers.id, id));
    return driver || undefined;
  }

  async getDriverByEmail(email: string): Promise<Driver | undefined> {
    const [driver] = await db.select().from(drivers).where(eq(drivers.email, email));
    return driver || undefined;
  }

  async getDriverWithVehicle(id: string): Promise<DriverWithVehicle | undefined> {
    const [driver] = await db.select().from(drivers).where(eq(drivers.id, id));
    if (!driver) return undefined;

    let veiculoFavorito: Vehicle | null = null;
    if (driver.veiculoFavoritoId) {
      const [vehicle] = await db
        .select()
        .from(vehicles)
        .where(eq(vehicles.id, driver.veiculoFavoritoId));
      veiculoFavorito = vehicle || null;
    }

    return {
      ...driver,
      veiculoFavorito,
    };
  }

  async getAllDrivers(): Promise<Driver[]> {
    return db.select().from(drivers);
  }

  async getAllDriversWithVehicles(): Promise<DriverWithVehicle[]> {
    const allDrivers = await db.select().from(drivers);
    return Promise.all(
      allDrivers.map(async (d) => {
        const withVehicle = await this.getDriverWithVehicle(d.id);
        return withVehicle!;
      })
    );
  }

  async createDriver(insertDriver: InsertDriver): Promise<Driver> {
    const [driver] = await db.insert(drivers).values(insertDriver).returning();
    return driver;
  }

  async updateDriver(id: string, updates: Partial<Driver>): Promise<Driver | undefined> {
    const [updated] = await db
      .update(drivers)
      .set(updates)
      .where(eq(drivers.id, id))
      .returning();
    return updated || undefined;
  }

  // Vehicles
  async getVehicle(id: string): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle || undefined;
  }

  async getVehicleWithDriver(id: string): Promise<VehicleWithDriver | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    if (!vehicle) return undefined;

    let motoristaPadrao: Driver | null = null;
    if (vehicle.motoristaPadraoId) {
      const [driver] = await db
        .select()
        .from(drivers)
        .where(eq(drivers.id, vehicle.motoristaPadraoId));
      motoristaPadrao = driver || null;
    }

    return {
      ...vehicle,
      motoristaPadrao,
    };
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    return db.select().from(vehicles);
  }

  async getAllVehiclesWithDrivers(): Promise<VehicleWithDriver[]> {
    const allVehicles = await db.select().from(vehicles);
    return Promise.all(
      allVehicles.map(async (v) => {
        const withDriver = await this.getVehicleWithDriver(v.id);
        return withDriver!;
      })
    );
  }

  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(insertVehicle).returning();
    return vehicle;
  }

  async updateVehicle(id: string, updates: Partial<Vehicle>): Promise<Vehicle | undefined> {
    const [updated] = await db
      .update(vehicles)
      .set(updates)
      .where(eq(vehicles.id, id))
      .returning();
    return updated || undefined;
  }

  async cleanOrphanVehicles(): Promise<number> {
    const allVehicles = await db.select().from(vehicles);
    const blockedVehicles = allVehicles.filter(v => v.currentShiftId !== null);
    
    let cleanedCount = 0;
    
    for (const vehicle of blockedVehicles) {
      if (!vehicle.currentShiftId) continue;
      
      const shift = await db
        .select()
        .from(shifts)
        .where(
          and(
            eq(shifts.id, vehicle.currentShiftId),
            eq(shifts.status, "em_andamento")
          )
        );
      
      if (shift.length === 0) {
        await db
          .update(vehicles)
          .set({ currentShiftId: null })
          .where(eq(vehicles.id, vehicle.id));
        cleanedCount++;
      }
    }
    
    return cleanedCount;
  }

  // Shifts
  async getShift(id: string): Promise<Shift | undefined> {
    const [shift] = await db.select().from(shifts).where(eq(shifts.id, id));
    return shift || undefined;
  }

  async getShiftWithDetails(id: string): Promise<ShiftWithDetails | undefined> {
    const [shift] = await db.select().from(shifts).where(eq(shifts.id, id));
    if (!shift) return undefined;

    const [driver] = await db.select().from(drivers).where(eq(drivers.id, shift.driverId));
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, shift.vehicleId));
    const shiftRides = await db.select().from(rides).where(eq(rides.shiftId, id));
    const shiftCosts = await db.select().from(costs).where(eq(costs.shiftId, id));

    return {
      ...shift,
      driver: driver || undefined,
      vehicle: vehicle || undefined,
      rides: shiftRides,
      costs: shiftCosts,
    };
  }

  async getActiveShiftByDriver(driverId: string): Promise<ShiftWithDetails | null> {
    const [activeShift] = await db
      .select()
      .from(shifts)
      .where(and(eq(shifts.driverId, driverId), eq(shifts.status, "em_andamento")));

    if (!activeShift) return null;

    return this.getShiftWithDetails(activeShift.id) as Promise<ShiftWithDetails>;
  }

  async getAllShifts(filters?: {
    driverId?: string;
    status?: string;
    from?: Date;
    to?: Date;
  }): Promise<ShiftWithDetails[]> {
    const conditions = [];
    
    if (filters?.driverId) {
      conditions.push(eq(shifts.driverId, filters.driverId));
    }
    
    if (filters?.status) {
      conditions.push(eq(shifts.status, filters.status));
    }
    
    if (filters?.from) {
      conditions.push(gte(shifts.inicio, filters.from));
    }
    
    if (filters?.to) {
      conditions.push(lte(shifts.inicio, filters.to));
    }

    let query = db.select().from(shifts);
    if (conditions.length === 1) {
      query = query.where(conditions[0]);
    } else if (conditions.length > 1) {
      query = query.where(and(...conditions));
    }

    const allShifts = await query;

    const shiftsWithDetails = await Promise.all(
      allShifts.map((s) => this.getShiftWithDetails(s.id))
    );

    return shiftsWithDetails.filter((s) => s !== undefined) as ShiftWithDetails[];
  }

  async createShift(insertShift: InsertShift): Promise<Shift> {
    const [shift] = await db.insert(shifts).values(insertShift).returning();
    return shift;
  }

  async updateShift(id: string, updates: Partial<Shift>): Promise<Shift | undefined> {
    const [updated] = await db
      .update(shifts)
      .set(updates)
      .where(eq(shifts.id, id))
      .returning();
    return updated || undefined;
  }

  // Rides
  async getRidesByShift(shiftId: string): Promise<Ride[]> {
    return db.select().from(rides).where(eq(rides.shiftId, shiftId));
  }

  async createRide(insertRide: InsertRide): Promise<Ride> {
    const [ride] = await db.insert(rides).values(insertRide).returning();
    return ride;
  }

  // Costs
  async getCostsByShift(shiftId: string): Promise<Cost[]> {
    return db.select().from(costs).where(eq(costs.shiftId, shiftId));
  }

  async createCost(insertCost: InsertCost): Promise<Cost> {
    const [cost] = await db.insert(costs).values(insertCost).returning();
    return cost;
  }

  // Logs
  async getAllLogs(filters?: {
    userId?: string;
    acao?: string;
    entidade?: string;
    from?: Date;
    to?: Date;
  }): Promise<LogWithUser[]> {
    const conditions = [];
    
    if (filters?.userId) {
      conditions.push(eq(logs.userId, filters.userId));
    }
    
    if (filters?.acao) {
      conditions.push(eq(logs.acao, filters.acao));
    }
    
    if (filters?.entidade) {
      conditions.push(eq(logs.entidade, filters.entidade));
    }
    
    if (filters?.from) {
      conditions.push(gte(logs.data, filters.from));
    }
    
    if (filters?.to) {
      conditions.push(lte(logs.data, filters.to));
    }

    let query = db.select().from(logs);
    if (conditions.length === 1) {
      query = query.where(conditions[0]);
    } else if (conditions.length > 1) {
      query = query.where(and(...conditions));
    }

    const allLogs = await query;

    // Fetch users for each log
    const logsWithUsers = await Promise.all(
      allLogs.map(async (log) => {
        const [user] = await db.select().from(drivers).where(eq(drivers.id, log.userId));
        return {
          ...log,
          user: user || undefined,
        };
      })
    );

    return logsWithUsers;
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const [log] = await db.insert(logs).values(insertLog).returning();
    return log;
  }
}

export const storage = new DatabaseStorage();
