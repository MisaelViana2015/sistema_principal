import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { loginSchema } from "@shared/schema";
import { calculateShiftTotals } from "../client/src/lib/calc";

// Middleware to check if user is authenticated
function requireAuth(req: Request, res: Response, next: Function) {
  if (!req.session || !req.session.userId) {
    return res.status(401).send("Não autorizado");
  }
  next();
}

// Middleware to check if user is admin
function requireAdmin(req: Request, res: Response, next: Function) {
  if (!req.session || !req.session.userId || !req.session.isAdmin) {
    return res.status(403).send("Acesso negado");
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, senha } = loginSchema.parse(req.body);

      const user = await storage.getDriverByEmail(email);
      if (!user) {
        return res.status(401).send("Email ou senha incorretos");
      }

      const isValidPassword = await bcrypt.compare(senha, user.senha);
      if (!isValidPassword) {
        return res.status(401).send("Email ou senha incorretos");
      }

      // Create session
      req.session.userId = user.id;
      req.session.isAdmin = user.role === "admin";

      // Don't send password in response
      const { senha: _, ...userWithoutPassword } = user;

      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(400).send(error.message || "Erro no login");
    }
  });

  app.get("/api/auth/me", requireAuth, async (req: Request, res: Response) => {
    try {
      const user = await storage.getDriver(req.session.userId!);
      if (!user) {
        return res.status(404).send("Usuário não encontrado");
      }

      const { senha: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar usuário");
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  // Driver routes
  app.get("/api/drivers", requireAuth, async (req: Request, res: Response) => {
    try {
      const isAdmin = req.session.isAdmin;

      if (isAdmin) {
        const drivers = await storage.getAllDriversWithVehicles();
        const driversWithoutPasswords = drivers.map(({ senha, ...d }) => d);
        res.json(driversWithoutPasswords);
      } else {
        const driver = await storage.getDriverWithVehicle(req.session.userId!);
        if (!driver) {
          return res.status(404).send("Motorista não encontrado");
        }
        const { senha, ...driverWithoutPassword } = driver;
        res.json([driverWithoutPassword]);
      }
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar motoristas");
    }
  });

  app.get("/api/drivers/me", requireAuth, async (req: Request, res: Response) => {
    try {
      const driver = await storage.getDriverWithVehicle(req.session.userId!);
      if (!driver) {
        return res.status(404).send("Motorista não encontrado");
      }

      const { senha, ...driverWithoutPassword } = driver;
      res.json(driverWithoutPassword);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar motorista");
    }
  });

  app.post("/api/drivers", requireAdmin, async (req: Request, res: Response) => {
    try {
      const { senha, ...driverData } = req.body;

      // Hash password
      const hashedPassword = await bcrypt.hash(senha, 10);

      const driver = await storage.createDriver({
        ...driverData,
        senha: hashedPassword,
      });

      // Log the action
      await storage.createLog({
        userId: req.session.userId!,
        acao: "criar_motorista",
        entidade: "Driver",
        referenciaId: driver.id,
        payload: { nome: driver.nome, email: driver.email },
      });

      const { senha: _, ...driverWithoutPassword } = driver;
      res.json(driverWithoutPassword);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao criar motorista");
    }
  });

  // Vehicle routes
  app.get("/api/vehicles", requireAuth, async (req: Request, res: Response) => {
    try {
      await storage.cleanOrphanVehicles();
      const vehicles = await storage.getAllVehiclesWithDrivers();
      
      // All users can see all vehicles to choose from
      // But non-admin users only get safe driver fields (id, nome) via explicit allowlist
      if (!req.session.isAdmin) {
        const sanitizedVehicles = vehicles.map(v => ({
          id: v.id,
          plate: v.plate,
          modelo: v.modelo,
          motoristaPadraoId: v.motoristaPadraoId,
          isActive: v.isActive,
          currentShiftId: v.currentShiftId,
          // Only expose safe fields from motoristaPadrao
          motoristaPadrao: v.motoristaPadrao ? {
            id: v.motoristaPadrao.id,
            nome: v.motoristaPadrao.nome,
          } : null,
        }));
        return res.json(sanitizedVehicles);
      }
      
      res.json(vehicles);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar veículos");
    }
  });

  app.post("/api/vehicles", requireAdmin, async (req: Request, res: Response) => {
    try {
      const vehicle = await storage.createVehicle(req.body);

      // Log the action
      await storage.createLog({
        userId: req.session.userId!,
        acao: "criar_veiculo",
        entidade: "Vehicle",
        referenciaId: vehicle.id,
        payload: { plate: vehicle.plate, modelo: vehicle.modelo },
      });

      res.json(vehicle);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao criar veículo");
    }
  });

  // Shift routes
  app.get("/api/shifts/active", requireAuth, async (req: Request, res: Response) => {
    try {
      const activeShift = await storage.getActiveShiftByDriver(req.session.userId!);
      res.json(activeShift);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar turno ativo");
    }
  });

  app.post("/api/shifts/start", requireAuth, async (req: Request, res: Response) => {
    try {
      const { vehicleId, kmInicial } = req.body;
      const driverId = req.session.userId!;

      // Clean orphan vehicles first (vehicles blocked without active shift)
      const cleanedCount = await storage.cleanOrphanVehicles();
      if (cleanedCount > 0) {
        console.log(`✨ Liberados ${cleanedCount} veículo(s) órfão(s)`);
      }

      // Check if driver already has an active shift
      const existingShift = await storage.getActiveShiftByDriver(driverId);
      if (existingShift) {
        return res.status(400).send("Você já possui um turno ativo");
      }

      // Check if vehicle is available
      const vehicle = await storage.getVehicle(vehicleId);
      if (!vehicle) {
        return res.status(404).send("Veículo não encontrado");
      }

      if (vehicle.currentShiftId) {
        return res.status(400).send(`Veículo em uso no turno ${vehicle.currentShiftId}`);
      }

      // Create shift
      const shift = await storage.createShift({
        driverId,
        vehicleId,
        inicio: new Date(),
        kmInicial: parseFloat(kmInicial),
        status: "em_andamento",
      });

      // Update vehicle's currentShiftId
      await storage.updateVehicle(vehicleId, { currentShiftId: shift.id });

      // Log the action
      await storage.createLog({
        userId: driverId,
        acao: "iniciar_turno",
        entidade: "Shift",
        referenciaId: shift.id,
        payload: { vehicleId, kmInicial },
      });

      const shiftWithDetails = await storage.getShiftWithDetails(shift.id);
      res.json(shiftWithDetails);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao iniciar turno");
    }
  });

  app.post("/api/shifts/end", requireAuth, async (req: Request, res: Response) => {
    try {
      const { shiftId, kmFinal } = req.body;
      const driverId = req.session.userId!;

      const shift = await storage.getShift(shiftId);
      if (!shift) {
        return res.status(404).send("Turno não encontrado");
      }

      if (shift.driverId !== driverId) {
        return res.status(403).send("Este turno não pertence a você");
      }

      if (shift.status !== "em_andamento") {
        return res.status(400).send("Este turno já foi encerrado");
      }

      const kmFinalNum = parseFloat(kmFinal);
      if (kmFinalNum < shift.kmInicial) {
        return res.status(400).send("KM final não pode ser menor que o inicial");
      }

      // Get rides and costs
      const rides = await storage.getRidesByShift(shiftId);
      const costs = await storage.getCostsByShift(shiftId);

      // Calculate totals
      const calculations = calculateShiftTotals(
        rides,
        costs,
        shift.kmInicial,
        kmFinalNum,
        new Date(shift.inicio),
        new Date()
      );

      // Update shift
      const updatedShift = await storage.updateShift(shiftId, {
        fim: new Date(),
        kmFinal: kmFinalNum,
        status: "finalizado",
        ...calculations,
      });

      // Free the vehicle
      await storage.updateVehicle(shift.vehicleId, { currentShiftId: null });

      // Log the action
      await storage.createLog({
        userId: driverId,
        acao: "finalizar_turno",
        entidade: "Shift",
        referenciaId: shiftId,
        payload: { kmFinal, ...calculations },
      });

      res.json(updatedShift);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao encerrar turno");
    }
  });

  app.get("/api/shifts", requireAuth, async (req: Request, res: Response) => {
    try {
      const { period, driverId, status } = req.query;
      
      // Security: Non-admin users can only see their own shifts
      let finalDriverId = driverId as string | undefined;
      if (!req.session.isAdmin) {
        finalDriverId = req.session.userId!;
      }

      let from: Date | undefined;
      let to: Date | undefined;

      // Handle period filter
      const now = new Date();
      if (period === "hoje") {
        from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        to = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
      } else if (period === "semana") {
        const dayOfWeek = now.getDay();
        const diff = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Monday = 0
        from = new Date(now);
        from.setDate(now.getDate() - diff);
        from.setHours(0, 0, 0, 0);
        to = new Date(now);
        to.setHours(23, 59, 59, 999);
      } else if (typeof period === "string" && period.startsWith("semana-")) {
        // Format: "semana-1-2024-10", "semana-2-2024-10", etc
        const parts = period.split("-");
        if (parts.length === 4) {
          const weekNum = parseInt(parts[1]);
          const year = parseInt(parts[2]);
          const month = parseInt(parts[3]) - 1; // JavaScript months are 0-indexed
          
          if (weekNum >= 1 && weekNum <= 4) {
            const weekStartDay = 1 + (weekNum - 1) * 7; // Week 1: day 1-7, Week 2: day 8-14, etc
            const lastDayOfMonth = new Date(year, month + 1, 0).getDate();
            const weekEndDay = Math.min(weekNum * 7, lastDayOfMonth);
            
            from = new Date(year, month, weekStartDay, 0, 0, 0);
            to = new Date(year, month, weekEndDay, 23, 59, 59);
          }
        }
      } else if (period === "mes") {
        from = new Date(now.getFullYear(), now.getMonth(), 1);
        to = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
      } else if (typeof period === "string" && period.startsWith("mes-")) {
        // Format: "mes-2025-11", "mes-2025-10", etc
        const parts = period.split("-");
        if (parts.length === 3) {
          const year = parseInt(parts[1]);
          const month = parseInt(parts[2]) - 1; // JavaScript months are 0-indexed
          from = new Date(year, month, 1, 0, 0, 0);
          to = new Date(year, month + 1, 0, 23, 59, 59);
        }
      }

      const shifts = await storage.getAllShifts({
        driverId: finalDriverId,
        status: status as string | undefined,
        from,
        to,
      });

      // Calculate aggregated totals for each shift
      const shiftsWithTotals = shifts.map(shift => {
        // Only recalculate if shift has actual rides or costs with data
        // Preserve database values if rides/costs are null, undefined, or empty arrays
        const hasActualRidesOrCosts = 
          (Array.isArray(shift.rides) && shift.rides.length > 0) || 
          (Array.isArray(shift.costs) && shift.costs.length > 0);
        
        if (hasActualRidesOrCosts) {
          return {
            ...shift,
            ...calculateShiftTotals(
              shift.rides || [],
              shift.costs || [],
              shift.kmInicial,
              shift.kmFinal || shift.kmInicial,
              shift.inicio,
              shift.fim || new Date()
            ),
          };
        } else {
          // Preserve database values when no rides/costs data exists
          return shift;
        }
      });

      res.json(shiftsWithTotals);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar turnos");
    }
  });

  // Ride routes
  app.get("/api/rides", requireAuth, async (req: Request, res: Response) => {
    try {
      const { shiftId } = req.query;
      if (!shiftId) {
        return res.status(400).send("shiftId é obrigatório");
      }

      // Security: Verify shift ownership for non-admin users
      if (!req.session.isAdmin) {
        const shift = await storage.getShift(shiftId as string);
        if (!shift || shift.driverId !== req.session.userId) {
          return res.status(403).send("Acesso negado");
        }
      }

      const rides = await storage.getRidesByShift(shiftId as string);
      res.json(rides);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar corridas");
    }
  });

  app.post("/api/rides", requireAuth, async (req: Request, res: Response) => {
    try {
      // Security: Verify shift ownership for non-admin users
      if (!req.session.isAdmin && req.body.shiftId) {
        const shift = await storage.getShift(req.body.shiftId);
        if (!shift || shift.driverId !== req.session.userId) {
          return res.status(403).send("Acesso negado");
        }
      }

      const ride = await storage.createRide({
        ...req.body,
        hora: req.body.hora ? new Date(req.body.hora) : new Date(),
      });

      // Log the action
      await storage.createLog({
        userId: req.session.userId!,
        acao: "adicionar_corrida",
        entidade: "Ride",
        referenciaId: ride.id,
        payload: { tipo: ride.tipo, valor: ride.valor },
      });

      res.json(ride);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao criar corrida");
    }
  });

  // Cost routes
  app.get("/api/costs", requireAuth, async (req: Request, res: Response) => {
    try {
      const { shiftId } = req.query;
      if (!shiftId) {
        return res.status(400).send("shiftId é obrigatório");
      }

      // Security: Verify shift ownership for non-admin users
      if (!req.session.isAdmin) {
        const shift = await storage.getShift(shiftId as string);
        if (!shift || shift.driverId !== req.session.userId) {
          return res.status(403).send("Acesso negado");
        }
      }

      const costs = await storage.getCostsByShift(shiftId as string);
      res.json(costs);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar custos");
    }
  });

  app.post("/api/costs", requireAuth, async (req: Request, res: Response) => {
    try {
      // Security: Verify shift ownership for non-admin users
      if (!req.session.isAdmin && req.body.shiftId) {
        const shift = await storage.getShift(req.body.shiftId);
        if (!shift || shift.driverId !== req.session.userId) {
          return res.status(403).send("Acesso negado");
        }
      }

      const cost = await storage.createCost({
        ...req.body,
        hora: req.body.hora ? new Date(req.body.hora) : new Date(),
      });

      // Log the action
      await storage.createLog({
        userId: req.session.userId!,
        acao: "adicionar_custo",
        entidade: "Cost",
        referenciaId: cost.id,
        payload: { tipo: cost.tipo, valor: cost.valor },
      });

      res.json(cost);
    } catch (error: any) {
      res.status(400).send(error.message || "Erro ao criar custo");
    }
  });

  // Log routes
  app.get("/api/logs", requireAuth, async (req: Request, res: Response) => {
    try {
      const { driverId, acao, entidade } = req.query;
      const isAdmin = req.session.isAdmin;

      // Non-admin users can only see their own logs
      const userIdFilter = isAdmin
        ? (driverId as string | undefined)
        : req.session.userId;

      const logs = await storage.getAllLogs({
        userId: userIdFilter,
        acao: acao as string | undefined,
        entidade: entidade as string | undefined,
      });

      res.json(logs);
    } catch (error: any) {
      res.status(500).send(error.message || "Erro ao buscar logs");
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
