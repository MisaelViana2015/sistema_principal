import { db } from "./db";
import { drivers, vehicles, shifts, type Driver } from "../shared/schema";
import { eq } from "drizzle-orm";

async function generateData() {
  console.log("🌱 Gerando dados de Setembro e Outubro 2025...");

  // Buscar motoristas
  const allDrivers = await db.select().from(drivers);
  const luan = allDrivers.find((d: Driver) => d.nome === "Luan");
  const gustavo = allDrivers.find((d: Driver) => d.nome === "Gustavo");
  const robson = allDrivers.find((d: Driver) => d.nome === "Robson");

  if (!luan || !gustavo || !robson) {
    console.error("❌ Motoristas não encontrados. Verifique os nomes: Luan, Gustavo, Robson");
    return;
  }

  const driverList = [luan, gustavo, robson];

  // Buscar veículos
  const allVehicles = await db.select().from(vehicles);
  if (allVehicles.length === 0) {
    console.error("❌ Nenhum veículo encontrado");
    return;
  }

  console.log(`✅ Encontrados ${driverList.length} motoristas e ${allVehicles.length} veículos`);

  // Limpar turnos de setembro e outubro 2025
  const deletedSept = await db.delete(shifts).where(
    eq(shifts.inicio, new Date(2025, 8, 1)) // Apenas exemplo, vamos deletar por range depois
  );
  console.log("🗑️  Limpando turnos antigos de setembro e outubro 2025...");

  let totalShifts = 0;

  // SETEMBRO 2025 (30 dias)
  for (let day = 1; day <= 30; day++) {
    const driver = driverList[day % driverList.length]; // Distribui entre os 3 motoristas
    const vehicle = allVehicles[day % allVehicles.length]; // Distribui entre os veículos

    // Valor alternado: R$ 500 nos dias ímpares, R$ 400 nos dias pares
    const valorBruto = day % 2 === 1 ? 500 : 400;
    const custos = 50; // R$ 50 de custos
    const liquido = valorBruto - custos;

    const inicio = new Date(2025, 8, day, 8, 0, 0); // Setembro é mês 8
    const fim = new Date(2025, 8, day, 18, 0, 0);
    const kmInicial = 10000 + (day - 1) * 150;
    const kmFinal = kmInicial + 120;

    await db.insert(shifts).values({
      driverId: driver.id,
      vehicleId: vehicle.id,
      inicio,
      fim,
      status: "finalizado",
      kmInicial,
      kmFinal,
      totalBruto: valorBruto,
      totalCustos: custos,
      liquido,
      totalCorridasApp: Math.floor(Math.random() * 10) + 5,
      totalCorridasParticular: Math.floor(Math.random() * 5) + 2,
    });

    totalShifts++;
  }

  console.log(`✅ ${totalShifts} turnos criados para Setembro 2025`);

  // OUTUBRO 2025 (31 dias)
  for (let day = 1; day <= 31; day++) {
    const driver = driverList[day % driverList.length]; // Distribui entre os 3 motoristas
    const vehicle = allVehicles[day % allVehicles.length]; // Distribui entre os veículos

    // Valor alternado: R$ 550 nos dias ímpares, R$ 500 nos dias pares
    const valorBruto = day % 2 === 1 ? 550 : 500;
    const custos = 55; // R$ 55 de custos
    const liquido = valorBruto - custos;

    const inicio = new Date(2025, 9, day, 8, 0, 0); // Outubro é mês 9
    const fim = new Date(2025, 9, day, 18, 0, 0);
    const kmInicial = 15000 + (day - 1) * 150;
    const kmFinal = kmInicial + 120;

    await db.insert(shifts).values({
      driverId: driver.id,
      vehicleId: vehicle.id,
      inicio,
      fim,
      status: "finalizado",
      kmInicial,
      kmFinal,
      totalBruto: valorBruto,
      totalCustos: custos,
      liquido,
      totalCorridasApp: Math.floor(Math.random() * 12) + 5,
      totalCorridasParticular: Math.floor(Math.random() * 6) + 2,
    });

    totalShifts++;
  }

  console.log(`✅ ${totalShifts} turnos criados no total (30 setembro + 31 outubro)`);
  console.log("🎉 Dados gerados com sucesso!");
}

generateData()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("❌ Erro:", err);
    process.exit(1);
  });
