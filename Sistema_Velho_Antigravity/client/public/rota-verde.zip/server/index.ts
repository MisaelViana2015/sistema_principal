import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pg from "pg";
import cors from "cors";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { runSeeds } from "./seeds";

const app = express();
const PgSession = connectPgSimple(session);

const connectionString = process.env.DATABASE_URL_PROD || process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error("DATABASE_URL não foi definida! Verifique os secrets.");
}

const sessionPool = new pg.Pool({ connectionString });

// 🔧 Permitir proxy do Replit (HTTPS real)
app.set("trust proxy", 1);

// 🚦 CORS: libera acesso do domínio publicado e preview
app.use(
  cors({
    origin: [
      "https://frota-eletrica-misaelviana.replit.app",
      "https://frota-eletrica-misaelviana.replit.dev",
      "http://localhost:3000",
    ],
    credentials: true,
  }),
);

// 🧩 Tipagem da sessão
declare module "express-session" {
  interface SessionData {
    userId: string;
    isAdmin: boolean;
  }
}

// 🍪 Sessão segura e compatível com ambiente HTTPS do Replit + Autoscale
// Detecta se está em ambiente com HTTPS (Replit.dev ou produção)
const isHttps = process.env.REPL_ID !== undefined || process.env.NODE_ENV === "production";
app.use(
  session({
    store: new PgSession({
      pool: sessionPool,
      tableName: "session",
      createTableIfMissing: true,
    }),
    secret: process.env.SESSION_SECRET || "frota-eletrica-secret-key-2024",
    resave: false,
    saveUninitialized: false,
    name: "sid",
    cookie: {
      httpOnly: true,
      sameSite: isHttps ? "none" : "lax", // none para HTTPS (cross-domain), lax para localhost
      secure: isHttps, // HTTPS quando está no Replit ou produção
      maxAge: 1000 * 60 * 60 * 6, // 6h
    },
  }),
);

// 🧠 Tipagem de request para rawBody (mantém igual ao seu)
declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

// 📦 Body parser
app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);
app.use(express.urlencoded({ extended: false }));

// 📝 Logger das rotas (mantive o seu)
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// 🚀 Inicialização principal
(async () => {
  // Seeds iniciais
  await runSeeds();

  // Registrar rotas
  const server = await registerRoutes(app);

  // Middleware de erro
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });

  // Dev x Produção
  // Sempre servir arquivos estáticos de produção se existirem
  // Isso garante que a URL pública funcione corretamente
  const publicPath = "./server/public";
  const fs = await import("fs");
  
  if (fs.existsSync(publicPath)) {
    log("📦 Servindo arquivos estáticos de produção (server/public)");
    serveStatic(app);
  } else {
    log("🔧 Modo desenvolvimento - usando Vite dev server");
    await setupVite(app, server);
  }

  // Porta padrão do Replit
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`✅ Servindo na porta ${port}`);
    },
  );
})();
