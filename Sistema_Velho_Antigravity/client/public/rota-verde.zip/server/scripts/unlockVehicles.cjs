// server/scripts/unlockVehicles.cjs
// SCRIPT FINAL - Libera veículos travados
// Uso: node server/scripts/unlockVehicles.cjs

require("dotenv/config");
const path = require("path");
const { eq, isNotNull } = require("drizzle-orm");

// Corrige o caminho exato do db.ts
const dbPath = path.join(__dirname, "..", "db");
const schemaPath = path.join(__dirname, "..", "..", "shared", "schema");

const { db } = require(dbPath);
const { vehicles, logs, shifts } = require(schemaPath);

(async () => {
  console.log("\n🚀 Iniciando script de liberação de veículos travados...\n");

  try {
    const travados = await db.select().from(vehicles).where(isNotNull(vehicles.currentShiftId));
    console.log(`🔎 Encontrados ${travados.length} veículo(s) com currentShiftId setado.`);

    if (travados.length === 0) {
      console.log("✅ Nenhum veículo bloqueado. Nada a fazer.");
      process.exit(0);
    }

    const freed = [];
    const problems = [];

    for (const v of travados) {
      try {
        const shiftId = v.currentShiftId;
        if (!shiftId) continue;

        const [refShift] = await db.select().from(shifts).where(eq(shifts.id, shiftId)).limit(1);

        if (!refShift) {
          await db.update(vehicles).set({ currentShiftId: null }).where(eq(vehicles.id, v.id));
          await db.insert(logs).values({
            userId: "admin-script",
            acao: "repair_liberar_veiculo",
            entidade: "vehicles",
            referenciaId: v.id,
            payload: { motivo: "turno_inexistente", prevShiftId: shiftId },
          });
          freed.push({ vehicleId: v.id, plate: v.plate, reason: "shift_not_found" });
          console.log(`🧹 Liberado ${v.plate || v.id} — turno não encontrado`);
          continue;
        }

        if (refShift.status !== "em_andamento") {
          await db.update(vehicles).set({ currentShiftId: null }).where(eq(vehicles.id, v.id));
          await db.insert(logs).values({
            userId: "admin-script",
            acao: "repair_liberar_veiculo",
            entidade: "vehicles",
            referenciaId: v.id,
            payload: { motivo: `turno_status_${refShift.status}`, prevShiftId: shiftId },
          });
          freed.push({ vehicleId: v.id, plate: v.plate, reason: `shift_status_${refShift.status}` });
          console.log(`🧹 Liberado ${v.plate || v.id} — turno ${refShift.status}`);
          continue;
        }

        problems.push({ vehicleId: v.id, plate: v.plate, shiftId, issue: "ativo" });
        console.log(`⏳ Mantido ${v.plate || v.id} — turno ativo`);
      } catch (innerErr) {
        console.error("⚠️ Erro no veículo", v.id, innerErr);
        problems.push({ vehicleId: v.id, issue: "erro_interno" });
      }
    }

    console.log("\n✅ Liberação concluída!");
    console.log("🔓 Liberados:", freed.length);
    console.log("⚠️ Mantidos:", problems.length);

    if (freed.length > 0) console.log("\n📋 Detalhes liberados:\n", freed);
    if (problems.length > 0) console.log("\n📋 Pendentes/ativos:\n", problems);

    process.exit(0);
  } catch (err) {
    console.error("\n❌ Erro fatal ao executar script:", err);
    process.exit(1);
  }
})();
