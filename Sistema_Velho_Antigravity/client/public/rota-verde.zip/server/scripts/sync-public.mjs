import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..', '..');
const distDir = path.join(rootDir, 'dist');
const publicDir = path.join(rootDir, 'server', 'public');

console.log('📦 Sync-Public: Copiando build para servidor...');
console.log(`   Origem: ${distDir}`);
console.log(`   Destino: ${publicDir}`);

if (!fs.existsSync(distDir)) {
  console.error('❌ Erro: Diretório dist/ não existe. Execute `npm run build` primeiro.');
  process.exit(1);
}

try {
  if (fs.existsSync(publicDir)) {
    console.log('   Limpando diretório existente...');
    fs.rmSync(publicDir, { recursive: true, force: true });
  }

  console.log('   Copiando arquivos...');
  fs.cpSync(distDir, publicDir, { recursive: true });

  const indexExists = fs.existsSync(path.join(publicDir, 'index.html'));
  if (!indexExists) {
    console.error('❌ Erro: index.html não encontrado após cópia!');
    process.exit(1);
  }

  console.log('✅ Build sincronizado com sucesso!');
  console.log(`   Arquivos disponíveis em: ${publicDir}`);
} catch (error) {
  console.error('❌ Erro ao sincronizar build:', error.message);
  process.exit(1);
}
