import { Router, Request, Response } from "express";
import { eq, and, isNotNull } from "drizzle-orm";
import { db } from "../db";
import { shifts, vehicles, logs, drivers } from "@shared/schema";

const router = Router();

/* =========================
   LISTAGENS DE APOIO (read-only)
   ========================= */

// GET /api/vehicles/locked => veículos com currentShiftId setado
router.get("/api/vehicles/locked", async (_req: Request, res: Response) => {
  const list = await db
    .select()
    .from(vehicles)
    .where(isNotNull(vehicles.currentShiftId));
  res.json(list);
});

// GET /api/shifts => lista geral; ?status=em_andamento para filtrar
router.get("/api/shifts", async (req: Request, res: Response) => {
  const status = (req.query.status as string) || undefined;
  if (status) {
    const list = await db
      .select()
      .from(shifts)
      .where(eq(shifts.status, status));
    return res.json(list);
  }
  const list = await db.select().from(shifts);
  res.json(list);
});

/* =========================
   FLUXO DE TURNO
   ========================= */

// 🔍 turno ativo do motorista logado
router.get("/api/shifts/active", async (req: Request, res: Response) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ message: "Não autenticado" });

  const [activeShift] = await db
    .select()
    .from(shifts)
    .where(and(eq(shifts.driverId, userId), eq(shifts.status, "em_andamento")))
    .limit(1);

  res.json(activeShift || null);
});

// 🚗 iniciar turno
router.post("/api/shifts/start", async (req: Request, res: Response) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ message: "Não autenticado" });

  const { vehicleId, kmInicial } = req.body;

  const [vehicle] = await db
    .select()
    .from(vehicles)
    .where(eq(vehicles.id, vehicleId))
    .limit(1);

  if (!vehicle)
    return res.status(404).json({ message: "Veículo não encontrado" });

  // veículo já aponta para turno?
  if (vehicle.currentShiftId) {
    const [refShift] = await db
      .select()
      .from(shifts)
      .where(eq(shifts.id, vehicle.currentShiftId))
      .limit(1);

    if (refShift && refShift.status === "em_andamento") {
      if (refShift.driverId !== userId) {
        return res.status(400).json({
          message: `Veículo em uso no turno ${refShift.id}. Escolha outro.`,
        });
      }
      // mesmo motorista: seguir no mesmo turno
      return res.json(refShift);
    }
  }

  // cria novo turno
  const [newShift] = await db
    .insert(shifts)
    .values({
      driverId: userId,
      vehicleId,
      inicio: new Date(),
      kmInicial,
      status: "em_andamento",
    })
    .returning();

  // vincula veículo ao turno
  await db
    .update(vehicles)
    .set({ currentShiftId: newShift.id })
    .where(eq(vehicles.id, vehicleId));

  // log
  await db.insert(logs).values({
    userId,
    acao: "iniciar_turno",
    entidade: "shifts",
    referenciaId: newShift.id,
    payload: { vehicleId, kmInicial },
  });

  res.json(newShift);
});

// 🏁 encerrar turno (motorista dono)
router.post("/api/shifts/end", async (req: Request, res: Response) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ message: "Não autenticado" });

  const { shiftId, kmFinal } = req.body;

  const [shift] = await db
    .select()
    .from(shifts)
    .where(eq(shifts.id, shiftId))
    .limit(1);

  if (!shift) return res.status(404).json({ message: "Turno não encontrado" });
  if (shift.driverId !== userId)
    return res
      .status(403)
      .json({ message: "Somente quem abriu pode encerrar" });

  await db
    .update(shifts)
    .set({ fim: new Date(), kmFinal, status: "finalizado" })
    .where(eq(shifts.id, shiftId));

  await db
    .update(vehicles)
    .set({ currentShiftId: null })
    .where(eq(vehicles.id, shift.vehicleId));

  await db.insert(logs).values([
    {
      userId,
      acao: "encerrar_turno",
      entidade: "shifts",
      referenciaId: shiftId,
      payload: { kmFinal },
    },
    {
      userId,
      acao: "liberar_veiculo",
      entidade: "vehicles",
      referenciaId: shift.vehicleId,
      payload: { motivo: "Encerramento normal do turno", shiftId },
    },
  ]);

  res.json({ success: true });
});

// ⚡ encerrar turno à força (admin)
router.post("/api/shifts/force-end", async (req: Request, res: Response) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ message: "Não autenticado" });

  const { shiftId, motivo } = req.body;

  const [user] = await db
    .select()
    .from(drivers)
    .where(eq(drivers.id, userId))
    .limit(1);
  if (!user || user.role !== "admin")
    return res.status(403).json({ message: "Apenas admin" });

  const [shift] = await db
    .select()
    .from(shifts)
    .where(eq(shifts.id, shiftId))
    .limit(1);
  if (!shift) return res.status(404).json({ message: "Turno não encontrado" });

  await db
    .update(shifts)
    .set({ fim: new Date(), status: "finalizado" })
    .where(eq(shifts.id, shiftId));

  await db
    .update(vehicles)
    .set({ currentShiftId: null })
    .where(eq(vehicles.id, shift.vehicleId));

  await db.insert(logs).values([
    {
      userId,
      acao: "encerrar_turno_forcado",
      entidade: "shifts",
      referenciaId: shiftId,
      payload: { motivo: motivo || "Encerrado via admin" },
    },
    {
      userId,
      acao: "liberar_veiculo",
      entidade: "vehicles",
      referenciaId: shift.vehicleId,
      payload: { motivo: "Encerramento forçado por admin", shiftId },
    },
  ]);

  res.json({ success: true, message: "Turno encerrado e veículo liberado" });
});

/* =========================
   REPARO AUTOMÁTICO (admin-only)
   ========================= */

router.post("/api/shifts/repair-stuck", async (req: Request, res: Response) => {
  const userId = (req.session as any)?.userId;
  if (!userId) return res.status(401).json({ message: "Não autenticado" });

  const [user] = await db
    .select()
    .from(drivers)
    .where(eq(drivers.id, userId))
    .limit(1);
  if (!user || user.role !== "admin")
    return res.status(403).json({ message: "Apenas administradores" });

  const stuckVehicles = await db
    .select()
    .from(vehicles)
    .where(isNotNull(vehicles.currentShiftId));

  const freedVehicles: any[] = [];
  const problems: any[] = [];

  for (const v of stuckVehicles) {
    const shiftId = v.currentShiftId;
    if (!shiftId) continue;

    const [refShift] = await db
      .select()
      .from(shifts)
      .where(eq(shifts.id, shiftId))
      .limit(1);

    if (!refShift || refShift.status === "finalizado") {
      await db
        .update(vehicles)
        .set({ currentShiftId: null })
        .where(eq(vehicles.id, v.id));

      freedVehicles.push({
        vehicleId: v.id,
        plate: v.plate,
        prevShiftId: shiftId,
        reason: refShift
          ? `shift_status_${refShift.status}`
          : "shift_not_found",
      });

      await db.insert(logs).values({
        userId,
        acao: "repair_liberar_veiculo",
        entidade: "vehicles",
        referenciaId: v.id,
        payload: {
          motivo: refShift
            ? `turno com status ${refShift.status}`
            : "turno inexistente",
          prevShiftId: shiftId,
        },
      });
    }
  }

  res.json({ freedVehicles, problems });
});

export default router;
