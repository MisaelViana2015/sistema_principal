import { storage } from "./storage";
import bcrypt from "bcryptjs";

export async function runSeeds() {
  console.log("🌱 Starting seeds...");

  // Check if data already exists
  const existingDriver = await storage.getDriverByEmail("programacao1215@hotmail.com");
  if (existingDriver) {
    console.log("✅ Seeds already exist, skipping...");
    return;
  }

  // Hash de senha padrão: "senha123"
  const defaultPasswordHash = await bcrypt.hash("senha123", 10);

  // Create drivers
  const misael = await storage.createDriver({
    nome: "Misael",
    email: "programacao1215@hotmail.com",
    senha: defaultPasswordHash,
    telefone: "(11) 99999-0001",
    veiculoFavoritoId: null,
    role: "admin",
    isActive: true,
  });

  const robson = await storage.createDriver({
    nome: "Robson",
    email: "robson@frota.com",
    senha: defaultPasswordHash,
    telefone: "(11) 99999-0002",
    veiculoFavoritoId: null,
    role: "driver",
    isActive: true,
  });

  const luan = await storage.createDriver({
    nome: "Luan",
    email: "luan@frota.com",
    senha: defaultPasswordHash,
    telefone: "(11) 99999-0003",
    veiculoFavoritoId: null,
    role: "driver",
    isActive: true,
  });

  const gustavo = await storage.createDriver({
    nome: "Gustavo",
    email: "gustavo@frota.com",
    senha: defaultPasswordHash,
    telefone: "(11) 99999-0004",
    veiculoFavoritoId: null,
    role: "driver",
    isActive: true,
  });

  console.log("✅ Drivers created");

  // Create vehicles
  const v1 = await storage.createVehicle({
    plate: "TQQ0A94",
    modelo: "Dolphi Mini PT",
    motoristaPadraoId: robson.id,
    isActive: true,
  });

  const v2 = await storage.createVehicle({
    plate: "TQQ0A07",
    modelo: "Dolphi Mini Azul",
    motoristaPadraoId: misael.id,
    isActive: true,
  });

  const v3 = await storage.createVehicle({
    plate: "TQS4C30",
    modelo: "Dolphi Mini BR",
    motoristaPadraoId: luan.id,
    isActive: true,
  });

  const v4 = await storage.createVehicle({
    plate: "TQU0H17",
    modelo: "Dolphi Mini BR",
    motoristaPadraoId: gustavo.id,
    isActive: true,
  });

  console.log("✅ Vehicles created");

  // Link favorite vehicles
  await storage.updateDriver(misael.id, { veiculoFavoritoId: v2.id });
  await storage.updateDriver(robson.id, { veiculoFavoritoId: v1.id });
  await storage.updateDriver(luan.id, { veiculoFavoritoId: v3.id });
  await storage.updateDriver(gustavo.id, { veiculoFavoritoId: v4.id });

  console.log("✅ Favorite vehicles linked");
  console.log("\n🎉 Seeds completed!");
  console.log("\n📋 Login credentials (senha para todos: senha123):");
  console.log("   Admin: programacao1215@hotmail.com");
  console.log("   Driver: robson@frota.com, luan@frota.com, gustavo@frota.com\n");
}
