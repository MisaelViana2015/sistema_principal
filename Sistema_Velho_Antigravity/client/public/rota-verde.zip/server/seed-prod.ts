import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import { drivers, vehicles } from "../shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Configurar WebSocket para Neon
neonConfig.webSocketConstructor = ws;

// Usar DATABASE_URL_PROD para produção
const DATABASE_URL = process.env.DATABASE_URL_PROD || process.env.DATABASE_URL;

if (!DATABASE_URL) {
  throw new Error("DATABASE_URL_PROD ou DATABASE_URL deve estar definido");
}

const pool = new Pool({ connectionString: DATABASE_URL });
const db = drizzle({ client: pool });

async function upsertDriver(
  nome: string,
  email: string,
  role: "admin" | "driver",
  telefone?: string
) {
  const existing = await db.select().from(drivers).where(eq(drivers.email, email));
  if (existing.length) {
    console.log(`  ↳ Driver ${email} já existe`);
    return existing[0];
  }

  const senha = await bcrypt.hash("senha123", 10);
  const [created] = await db
    .insert(drivers)
    .values({
      nome,
      email,
      senha,
      telefone: telefone || null,
      role,
      isActive: true,
      veiculoFavoritoId: null,
    })
    .returning();
  console.log(`  ✓ Driver ${email} criado`);
  return created;
}

async function upsertVehicle(plate: string, modelo: string, isActive = true) {
  const existing = await db.select().from(vehicles).where(eq(vehicles.plate, plate));
  if (existing.length) {
    console.log(`  ↳ Veículo ${plate} já existe`);
    return existing[0];
  }

  const [created] = await db
    .insert(vehicles)
    .values({
      plate,
      modelo,
      isActive,
      motoristaPadraoId: null,
      currentShiftId: null,
    })
    .returning();
  console.log(`  ✓ Veículo ${plate} criado`);
  return created;
}

async function main() {
  console.log("🌱 Seeding produção...");

  // 1) Motoristas
  console.log("\n1️⃣ Criando motoristas...");
  const admin = await upsertDriver("Misael", "programacao1215@hotmail.com", "admin", "(11) 99999-0001");
  const robson = await upsertDriver("Robson", "robson@frota.com", "driver", "(11) 99999-0002");
  const luan = await upsertDriver("Luan", "luan@frota.com", "driver", "(11) 99999-0003");
  const gustavo = await upsertDriver("Gustavo", "gustavo@frota.com", "driver", "(11) 99999-0004");

  // 2) Veículos
  console.log("\n2️⃣ Criando veículos...");
  const v1 = await upsertVehicle("TQQ0A94", "Dolphi Mini PT");
  const v2 = await upsertVehicle("TQQ0A07", "Dolphi Mini Azul");
  const v3 = await upsertVehicle("TQS4C30", "Dolphi Mini BR");
  const v4 = await upsertVehicle("TQU0H17", "Dolphi Mini BR");

  // 3) Atualizar motoristas padrão dos veículos
  console.log("\n3️⃣ Vinculando motoristas aos veículos...");
  await db.update(vehicles).set({ motoristaPadraoId: robson.id }).where(eq(vehicles.id, v1.id));
  await db.update(vehicles).set({ motoristaPadraoId: admin.id }).where(eq(vehicles.id, v2.id));
  await db.update(vehicles).set({ motoristaPadraoId: luan.id }).where(eq(vehicles.id, v3.id));
  await db.update(vehicles).set({ motoristaPadraoId: gustavo.id }).where(eq(vehicles.id, v4.id));
  console.log("  ✓ Motoristas padrão vinculados");

  // 4) Favoritos (campo veiculoFavoritoId no driver)
  console.log("\n4️⃣ Configurando veículos favoritos...");
  await db.update(drivers).set({ veiculoFavoritoId: v1.id }).where(eq(drivers.id, robson.id));
  await db.update(drivers).set({ veiculoFavoritoId: v2.id }).where(eq(drivers.id, admin.id));
  await db.update(drivers).set({ veiculoFavoritoId: v3.id }).where(eq(drivers.id, luan.id));
  await db.update(drivers).set({ veiculoFavoritoId: v4.id }).where(eq(drivers.id, gustavo.id));
  console.log("  ✓ Veículos favoritos configurados");

  console.log("\n✅ Seed de produção finalizado!");
  console.log("\n📋 Credenciais de login:");
  console.log("   Admin: programacao1215@hotmail.com / senha123");
  console.log("   Drivers: robson@frota.com, luan@frota.com, gustavo@frota.com / senha123\n");
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("❌ Erro ao executar seed:", e);
    process.exit(1);
  });
