## Overview
**Rota Verde** is a comprehensive management system for electric vehicle fleets, designed with a mobile-first approach. It handles shift management, ride tracking, cost recording, and automatic revenue sharing calculations (60% company / 40% driver). The system provides real-time KPIs, detailed dashboards with CSV export, and an audit log for all critical actions, aiming to streamline operations for electric vehicle fleet businesses.

**Current Version:** 1.5 (November 2025)
**Official Name:** Rota Verde

## Version History

### Version 1.5 (November 2025)
**Critical Architecture Simplification:**
- **Dashboard Removal**: Permanently removed Dashboard feature due to persistent production cache issues
  - Deleted file: `client/src/pages/Dashboard.tsx`
  - Removed route: `/dashboard` from `client/src/App.tsx`
  - Removed navigation item from `client/src/components/BottomNav.tsx`
  - Navigation now shows 4 tabs: Turno, Veículos, Motoristas, Logs
  - Reason: Production deployment (.replit.app) served stale bundle despite code fixes, caused extreme user frustration
  - Alternative: Users can view operational data via Logs page and Encerrar Turno summaries
- **Build Cache Fixes**: Resolved Vite serving outdated `/src/main.tsx` path
  - Fixed `client/index.html` to reference correct path: `/client/src/main.tsx`
  - Deleted legacy `src/` folder containing mockado financial data (R$ 2.4B phantom values)
  - Deleted `dist/` folder with stale production builds
  - Cleared Vite cache (`node_modules/.vite`, `.vite`)

### Version 1.4 (November 2025)
**Critical UX & Security Fixes:**
- **Universal Vehicle Visibility**: All authenticated users can now see all available vehicles
  - Previous behavior: Drivers only saw their assigned vehicle
  - New behavior: All drivers see all 4 vehicles to choose from
  - Favorite vehicle marked with yellow star (⭐) for each driver
  - Enables operational flexibility: drivers can select alternate vehicles when favorite is unavailable (maintenance, etc.)
  - API endpoint: `GET /api/vehicles` with role-based sanitization
- **Data Privacy Enhancement**: Implemented explicit allowlist sanitization for driver data
  - Admin users: Full visibility of all driver fields (email, telefone, senha, etc.)
  - Non-admin users: Only see safe fields (id, nome) in motoristaPadrao
  - Protection against future field leakage via explicit allowlist pattern
  - Sanitization applied in `server/routes.ts` lines 148-163
  - E2E validated: Drivers cannot see other drivers' contact information
- **Dashboard Driver Filter (Admin-Only)**: Fixed role-based visibility bug
  - Admin users: See "Motorista" dropdown with 5 options (Todos, Luan, Gustavo, Robson, Misael)
  - Driver users: Dropdown hidden, automatically filtered to own data only
  - Bug fix: Replaced duplicate `/api/auth/me` query with `useAuth()` hook
  - Single source of truth for authentication via AuthContext
  - Component: `client/src/pages/Dashboard.tsx`
- **Database Cleanup**: Removed orphan active shift causing phantom dashboard data
  - Deleted stale shift record from Luan
  - Database now 100% clean: 0 shifts, 0 rides, 0 costs
  - Preserved: 4 drivers, 4 vehicles, favorite vehicle configurations
  - Dashboard correctly displays R$ 0,00 when no data exists
- **Testing Validated**:
  - ✅ All drivers see 4 vehicles with only their favorite showing star
  - ✅ Luan: TQS4C30 auto-selected and starred
  - ✅ Misael: TQQ0A07 auto-selected and starred
  - ✅ Admin sees motorista dropdown with all options
  - ✅ Driver does NOT see motorista dropdown (auto-filtered to own data)
  - ✅ Dashboard shows zeroed metrics when no shifts exist
  - ✅ Non-admin API responses sanitized (no email/telefone leakage)
  - ✅ Admin API responses show full driver details

### Version 1.3 (November 2025)
**UX Enhancements & Cache Fixes:**
- **Auto-selection of Favorite Vehicle**: Drivers' favorite vehicles are now automatically pre-selected when starting a new shift
  - Component: `client/src/components/turno/TurnoInativo.tsx`
  - useEffect detects `driver.veiculoFavoritoId` and auto-selects if vehicle is available
  - Drivers can still manually select a different vehicle if needed (e.g., favorite in maintenance)
  - Visual feedback: selected vehicle shows colored border, checkmark icon, and yellow star
- **Online Status Indicator**: Motoristas page displays real-time status of drivers
  - Badge "Em Turno" (green) shows drivers currently working
  - Badge "Inativo" (gray) shows offline drivers
  - Already implemented in `client/src/pages/Motoristas.tsx`
- **React Query Cache Fixes**: Resolved cross-user data leakage issues
  - Added `queryClient.clear()` on logout to prevent stale data
  - Implemented `refetchOnMount: "always"` on critical queries (/api/vehicles, /api/drivers/me)
  - Ensures each user sees fresh data after login, preventing cache from previous user
- **Testing Validated**:
  - ✅ Luan logs in → TQS4C30 auto-selected (his favorite)
  - ✅ Logout clears all cache
  - ✅ Misael logs in → TQQ0A07 auto-selected (his favorite, not Luan's cached data)
  - ✅ Online status updates correctly when drivers start/end shifts

### Version 1.2 (November 2025)
**Critical Security Enhancements:**
- **Comprehensive Access Control**: Implemented ownership verification across all endpoints
  - GET `/api/vehicles`: Non-admin users only see available vehicles (unassigned or their own)
  - GET `/api/rides`, GET `/api/costs`: Non-admin users only access their own shift data
  - POST `/api/rides`, POST `/api/costs`: Non-admin users can only create records in their own shifts
  - Prevents privilege escalation and cross-driver data manipulation
- **Database Cleanup**: Removed all test data (105 shifts, 281 rides, 42 costs, 28 logs)
  - System now in production-ready state with clean database
  - Preserved 4 drivers and 4 vehicles for production use
- **Testing Validated**: 
  - Admin (Misael) correctly sees all 4 vehicles
  - Driver (Luan) correctly sees only his assigned vehicle (TQS4C30)
  - Favorite vehicle displays correctly per user

### Version 1.1 (November 2025)
**Major UI/UX Enhancements:**
- **IconBadge Component**: Created universal colored circular badge component with shadows and gradients
  - Supports 4 sizes: xs (6x6), sm (8x8), md (10x10), lg (12x12)
  - 10 vibrant colors: green, orange, blue, purple, red, yellow, teal, cyan, indigo, amber
  - Used throughout the system for visual hierarchy and modern aesthetics
- **Dark/Light Theme Toggle**: Added theme switcher in header
  - Button displays moon icon (light mode) or sun icon (dark mode)
  - Instant theme switching with localStorage persistence
  - Self-contained component without Context API complexity
  - Located in TopBar between Admin/Settings and Logout buttons
- **Enhanced Encerrar Turno Page**:
  - Section headers (Aplicativo/Particular) use large IconBadges (size="md")
  - Dados Operacionais metrics display with colored IconBadges (size="sm"): KM Rodados (indigo), Valor por KM (amber), Total de Corridas (purple), Ticket Médio (cyan)
  - Secondary metrics use smaller IconBadges (size="xs")
- **Dashboard Improvements**:
  - Added "DESCONTOS" column to financial chart with 5 metrics display
  - Chart legend order: Bruto, Descontos, Empresa (60%), Líquido, Motorista (40%)
  - Custom colors and shadows for all chart elements
- **Security**: Comprehensive backend access control with role-based validation in shift and chart-data routes

## User Preferences
I prefer detailed explanations.
I want iterative development.
Ask before making major changes.
Do not make changes to the folder `Z`.
Do not make changes to the file `Y`.

## System Architecture

### UI/UX Decisions
- **Mobile-first design** with a bottom navigation bar.
- **Dark/Light Theme Support** (v1.1): Full theme switching capability
  - Component: `client/src/components/ThemeToggle.tsx` (self-contained with local state)
  - Toggle button in header with moon/sun icons from Lucide React
  - Theme persisted in localStorage between sessions
  - CSS classes configured in `index.css` for :root and .dark
- **IconBadge System** (v1.1): Universal colored circular badges with shadows and gradients for visual hierarchy
  - Component location: `client/src/components/IconBadge.tsx`
  - Size hierarchy: md for section headers, sm for operational metrics, xs for secondary indicators
  - Color palette: green, orange, blue, purple, red, yellow, teal, cyan, indigo, amber
  - Used throughout: KPI cards, section headers, cost type buttons, operational metrics
- **Real-time KPI cards** for quick insights with vibrant color gradients and Lucide React icons wrapped in IconBadges.
- **Large touch-friendly buttons** for forms.
- **Typography**: Inter font for text, JetBrains Mono for plates/values.
- **Color Scheme**: Configurable in `index.css`, with vibrant, distinct colors for dashboard KPIs and charts (e.g., gradients for different metrics, unique colors per driver in bar charts).
- **Component Library**: shadcn/ui for consistent UI elements.
- **Vehicle Selection**: Visual color-coded system for vehicles based on model (Amber for BR, Blue for Azul, Grey for PT), with distinct borders and check icons for selected vehicles.
- **Vehicle Cards**: Color-coded with left borders and gradients matching model type (Blue for Azul, Amber for BR, Grey for PT).
- **Icons**: Lucide React icons used throughout, wrapped in IconBadges for enhanced visual appeal.
- **Required Fields**: Highlighted with a red asterisk (*) and descriptive placeholders.
- **Live Timer**: Active shift page displays "Tempo Trabalhado" updating every minute.
- **Toasts**: Success notifications reduced to 800ms for quicker feedback.
- **No Emojis**: All emojis removed to prevent InvalidCharacterError; replaced with modern Lucide React icons and IconBadges.

### Technical Implementations
- **Frontend**: React, Vite, Tailwind CSS, shadcn/ui.
- **Backend**: Node.js with Express.
- **Database**: PostgreSQL (Neon) managed with Drizzle ORM.
- **Authentication**: Session-based with role management (admin/driver).
- **Core Logic**:
    - **Shift Management**: One active shift per driver, one vehicle per shift, KM final ≥ KM inicial validation.
    - **Financial Calculations**: Automated 60/40 revenue split, calculation of gross, net, costs, per-kilometer value, and average tickets.
    - **Data Formatting**: pt-BR localization for currency (R$), date/time (24h), KM with thousands separator, and duration in "Xh Ymin".
    - **Audit Logs**: Comprehensive logging of all critical actions.

### Feature Specifications
- **User Roles**: Admin (full access, driver/vehicle creation) and Driver (shift, ride, cost management).
- **Dashboard**: 
  - **Period Filters**: Intuitive month dropdown with readable labels ("Mês Atual", "Outubro/24"...) spanning from October 2024 to current month (auto-refreshes on change)
  - **Week Toggle Buttons**: Four buttons (1-4) that activate/deactivate to filter by specific week or show full month
  - **Dynamic Status Label**: Displays current filter state (e.g., "Exibindo: Outubro/24 – Semana 2" or "Exibindo: Outubro/24 (mês completo)")
  - **Adaptive Chart**: Automatically switches between monthly view (4 weeks: S1-S4) and weekly view (7 days: Seg-Dom) based on week selection
  - **Metrics Display** (v1.1): Shows 5 metrics with custom colors - Bruto (amber), Descontos (red), Líquido (green), Empresa 60% (purple), Motorista 40% (blue)
  - **Chart Legend Order**: Bruto, Descontos, Empresa (60%), Líquido, Motorista (40%) - Note: Recharts controls final rendering order
  - **CSV Export**: Download filtered data in CSV format
  - **KPI Cards**: All cards use IconBadge component with vibrant colors and shadows
- **Vehicle Management**: Listing with status.
- **Driver Management**: Listing.
- **Admin Panel**: Dedicated interface for creating drivers and vehicles.
- **API**: Comprehensive RESTful API for all core functionalities, including:
  - Authentication and user management
  - Shift operations with period filtering (`mes-YYYY-MM` or `semana-X-YYYY-MM` format)
  - Ride/cost recording
  - Chart data aggregation (`/api/shifts/chart-data`) with weekly or daily grouping
  - Audit logging
- **Query Filtering**: Advanced filtering for shifts and logs by driver, status, date ranges, and period types with mobile-friendly UI.

## External Dependencies
- **PostgreSQL (Neon)**: Primary database for persistent storage.
- **Drizzle ORM**: Used for interacting with the PostgreSQL database.
- **connect-pg-simple**: PostgreSQL session store for Node.js, ensuring compatibility with autoscaling environments.
- **Recharts**: JavaScript charting library for dashboard visualizations.
- **lucide-react**: Icon library used in KPI cards.