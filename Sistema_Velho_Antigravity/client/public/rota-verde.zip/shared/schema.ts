import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, real, integer, json, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Driver (motorista)
export const drivers = pgTable("drivers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nome: text("nome").notNull(),
  email: text("email").notNull().unique(),
  senha: text("senha").notNull(),
  telefone: text("telefone"),
  veiculoFavoritoId: varchar("veiculo_favorito_id"),
  isActive: boolean("is_active").notNull().default(true),
  role: text("role").notNull().default("driver"), // "driver" | "admin"
});

// Vehicle (veículo)
export const vehicles = pgTable("vehicles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  plate: text("plate").notNull().unique(),
  modelo: text("modelo").notNull(),
  motoristaPadraoId: varchar("motorista_padrao_id"),
  isActive: boolean("is_active").notNull().default(true),
  currentShiftId: varchar("current_shift_id"),
});

// Shift (turno)
export const shifts = pgTable("shifts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  driverId: varchar("driver_id").notNull(),
  vehicleId: varchar("vehicle_id").notNull(),
  inicio: timestamp("inicio").notNull(),
  fim: timestamp("fim"),
  kmInicial: real("km_inicial").notNull(),
  kmFinal: real("km_final"),
  status: text("status").notNull().default("em_andamento"), // "em_andamento" | "finalizado"
  
  // Agregados (preenchidos no encerramento)
  totalApp: real("total_app").default(0),
  totalParticular: real("total_particular").default(0),
  totalBruto: real("total_bruto").default(0),
  totalCustos: real("total_custos").default(0),
  liquido: real("liquido").default(0),
  repasseEmpresa: real("repasse_empresa").default(0),
  repasseMotorista: real("repasse_motorista").default(0),
  totalCorridasApp: integer("total_corridas_app").default(0),
  totalCorridasParticular: integer("total_corridas_particular").default(0),
  totalCorridas: integer("total_corridas").default(0),
  duracaoMin: integer("duracao_min").default(0),
  valorKm: real("valor_km").default(0),
});

// Ride (corrida)
export const rides = pgTable("rides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shiftId: varchar("shift_id").notNull(),
  tipo: text("tipo").notNull(), // "App" | "Particular"
  valor: numeric("valor", { precision: 12, scale: 2 }).notNull(),
  hora: timestamp("hora").notNull(),
});

// Cost (custo)
export const costs = pgTable("costs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shiftId: varchar("shift_id").notNull(),
  tipo: text("tipo").notNull(), // "Recarga APP" | "Recarga Carro" | "Outros"
  valor: numeric("valor", { precision: 12, scale: 2 }).notNull(),
  observacao: text("observacao"),
  hora: timestamp("hora").notNull(),
});

// Log (auditoria)
export const logs = pgTable("logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  acao: text("acao").notNull(),
  entidade: text("entidade").notNull(),
  referenciaId: varchar("referencia_id").notNull(),
  payload: json("payload"),
  data: timestamp("data").notNull().default(sql`now()`),
});

// Insert schemas
export const insertDriverSchema = createInsertSchema(drivers).omit({ id: true });
export const insertVehicleSchema = createInsertSchema(vehicles).omit({ id: true, currentShiftId: true });
export const insertShiftSchema = createInsertSchema(shifts).omit({ 
  id: true, 
  fim: true, 
  kmFinal: true, 
  totalApp: true,
  totalParticular: true,
  totalBruto: true,
  totalCustos: true,
  liquido: true,
  repasseEmpresa: true,
  repasseMotorista: true,
  totalCorridasApp: true,
  totalCorridasParticular: true,
  totalCorridas: true,
  duracaoMin: true,
  valorKm: true,
});
export const insertRideSchema = createInsertSchema(rides).omit({ id: true });
export const insertCostSchema = createInsertSchema(costs).omit({ id: true });
export const insertLogSchema = createInsertSchema(logs).omit({ id: true, data: true });

// Login schema
export const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  senha: z.string().min(1, "Senha obrigatória"),
});

// Types
export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = z.infer<typeof insertDriverSchema>;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Shift = typeof shifts.$inferSelect;
export type InsertShift = z.infer<typeof insertShiftSchema>;
export type Ride = typeof rides.$inferSelect;
export type InsertRide = z.infer<typeof insertRideSchema>;
export type Cost = typeof costs.$inferSelect;
export type InsertCost = z.infer<typeof insertCostSchema>;
export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type Login = z.infer<typeof loginSchema>;

// Extended types for API responses
export type DriverWithVehicle = Driver & {
  veiculoFavorito?: Vehicle | null;
};

export type VehicleWithDriver = Vehicle & {
  motoristaPadrao?: Driver | null;
};

export type ShiftWithDetails = Shift & {
  driver?: Driver;
  vehicle?: Vehicle;
  rides?: Ride[];
  costs?: Cost[];
};

export type LogWithUser = Log & {
  user?: Driver;
};
