
import * as ridesRepository from "./rides.repository.js";

export async function getAllRides(
    page: number = 1,
    limit: number = 10,
    filters?: {
        driverId?: string;
        vehicleId?: string;
        shiftId?: string;
        startDate?: string;
        endDate?: string;
    }
) {
    return await ridesRepository.getWithPagination(page, limit, filters);
}

import { db } from "../../core/db/connection.js";
import { shifts, rides } from "../../../shared/schema.js";
import { eq, sql } from "drizzle-orm";

// Note: shifts, rides, eq, sql imports are already present/needed
import { recalculateShiftTotals } from "../shifts/shifts.service.js";

export async function createRide(data: typeof rides.$inferInsert) {
    // 1. Create the ride
    const newRide = await ridesRepository.create(data);

    // 2. Recalculate shift totals
    if (data.shiftId) {
        await recalculateShiftTotals(data.shiftId);
    }

    return newRide;
}

export async function updateRide(id: string, data: Partial<typeof rides.$inferInsert>) {
    // 1. Get original ride to check shiftId
    const original = await ridesRepository.getById(id);
    if (!original) throw new Error("Corrida não encontrada");

    // 2. Update ride
    const updated = await ridesRepository.update(id, data);

    // 3. Recalculate totals for involved shifts
    if (original.shiftId) {
        await recalculateShiftTotals(original.shiftId);
    }
    // If shiftId changed (unlikely but possible), recalculate the new shift too
    if (data.shiftId && data.shiftId !== original.shiftId) {
        await recalculateShiftTotals(data.shiftId);
    }

    return updated;
}

export async function deleteRide(id: string) {
    // 1. Get ride to check shiftId
    const ride = await ridesRepository.getById(id);
    if (!ride) throw new Error("Corrida não encontrada");

    // 2. Delete ride
    await ridesRepository.deleteRide(id);

    // 3. Recalculate totals
    if (ride.shiftId) {
        try {
            await recalculateShiftTotals(ride.shiftId);
        } catch (error) {
            console.warn(`[WARN] Could not recalculate totals for shift ${ride.shiftId} after deleting ride ${id}. Shift might be missing.`, error);
        }
    }

    return true;
}
