export const SYSTEM_VERSION = "v1.2.0 - Fix Login Loop & Add Version Label";
